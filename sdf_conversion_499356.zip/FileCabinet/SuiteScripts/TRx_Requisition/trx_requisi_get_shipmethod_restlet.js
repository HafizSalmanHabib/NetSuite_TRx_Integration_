/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search'], function (search) {
  
    function getShipItemData(params) {
      var shipItemData = [];
      
      // Define a search to retrieve ship item data
      var shipItemSearch = search.create({
        type: 'shipitem', // Record type for ship items
        columns: ['itemid', 'displayname', 'subsidiary','isinactive'],
        filter:[["isinactive","is","F"]]
      });
      
      // Add filter for subsidiary if provided in the request
      if (params.subsidiary) {
        shipItemSearch.filters.push(
          search.createFilter({
            name: 'subsidiary',
            operator: search.Operator.ANYOF,
            values: [params.subsidiary]
          })
        );
      }
      
      // Run the search and iterate through the results
      shipItemSearch.run().each(function(result) {
        var shipItemId = result.id;
        
        var isinactive = result.getValue('isinactive');
        var shipItemDisplayName = result.getValue('displayname');
        var subsidiary = result.getValue('subsidiary');
        
        // Add ship item data to the array
        shipItemData.push({
          shipItemId: shipItemId,
          isinactive:isinactive,
          shipItemDisplayName: shipItemDisplayName,
          subsidiary: subsidiary
        });
        
        return true; // Continue processing results
      });
      
      return shipItemData;
    }
    
    function doGet(params) {
      try {
        // var params = context.request.parameters; // Get the request parameters
        var shipItemResults = getShipItemData(params);
        
        var response = {
          success: true,
          shipItems: shipItemResults
        };
        
        return JSON.stringify(response); // Return JSON string
      } catch (e) {
        log.error({
          title: 'Error in GET request',
          details: e.message
        });
        return JSON.stringify({
          success: false,
          error: e.message
        }); // Return error as JSON string
      }
    }
    
    function doPost(context) {
      // Handle POST requests if needed
    }
    
    function doPut(context) {
      // Handle PUT requests if needed
    }
  
    return {
      get: doGet,
      post: doPost,
      put: doPut
    };
  });
  