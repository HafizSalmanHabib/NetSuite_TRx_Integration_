/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */

define(['N/record', 'N/runtime', 'N/url'], function(record, runtime, url) {
    function getRestletURLs() {  
        var restletScriptIds = [
            { scriptId: "customscript_get_po_for_req_manage", key: "PO API" },
            { scriptId: "customscript_get_customer_for_req_manag", key: "Customer API" },
            { scriptId: "customscript_trx_req_mana_item_restlet", key: "Item API" },
            { scriptId: "customscript_trx_req_mana_vendor_restlet", key: "Vendor API" },
            { scriptId: "customscript_trx_req_mana_subsidary", key: "Subsidiary API" },
           { scriptId: "customscript_trx_req_bill_management", key: "VendorBill API" },
           { scriptId: "customscript_trx_req_mana_account_rest", key: "Accounts API" },
          { scriptId: "customscript_trx_req_mana_depart_restlet", key: "Department API" },
          { scriptId: "customscript_trx_req_mana_class_restlet", key: "Class API" },
          { scriptId: "customscript_trx_req_mana_terms_restlet", key: "Terms API" },
          { scriptId: "customscript_trx_req_ship_metod_restlet", key: "Shipping Method API" },
          { scriptId: "customscript_trx_req_emp_restlet", key: "Employee API" },
          { scriptId: "customscript_get_customer_adr_trx_restle", key: "Customer Address API" },
          { scriptId: "customscript_trx_req_mana_loca_restlet", key: "Location API" }
          
        ];
    
        var urls = {};
        restletScriptIds.forEach(function(script) {
            var restletUrl = url.resolveScript({
                scriptId: script.scriptId,
                deploymentId: '1',
                returnExternalUrl: true
            });
            urls[script.key] = restletUrl;
        });
    
         return JSON.stringify(urls);
    }
    
  
    function doGet() {
      return getRestletURLs();
    }
  
    return {
      get: doGet
    };
  });
  