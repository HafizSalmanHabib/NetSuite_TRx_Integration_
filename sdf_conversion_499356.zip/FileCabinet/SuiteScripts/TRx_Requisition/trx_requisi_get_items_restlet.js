/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/record'], function (search, record) {

    /**
     * Executes when a GET request is made to the RESTlet.
     * 
     * @param {Object} params - Search criteria object.
     * @param {String} params.name - The name of the item to search for.
     * @param {Number} [startIndex=0] - The start index for the search results. Default is 0.
     * @param {Number} [batchSize=100] - The number of search results to return in a batch. Default is 100.
     * 
     * @returns {Array} 
     */
    function getitems(params) {
        try {
            var itemTypes = ["InvtPart", "OthCharge", "Service","NonInvtPart"]; // Default item types

        if (params.type) {
            itemTypes = [params.type]; // Use the specified item type
        }
            var itemSearchObj = search.create({
                type: "item",
                filters: [
                  ["type", "anyof", itemTypes], "AND", 
                  ["isinactive","is","F"],"AND", 
                  ["subtype","noneof","Sale"],"AND", 
                  ["islotitem","is","F"], 
                  "AND", 
                  ["isserialitem","is","F"],
              ],
                columns: [
                    search.createColumn({
                        name: "itemid",
                        sort: search.Sort.ASC
                    }),
                    "internalid",
                    "isinactive",
                    "displayname",
                    "salesdescription",
                    "type",
                    "baseprice",
                    "subtype",
                    "isfulfillable",
                    // "expenseaccount",
                    // "incomeaccount",
                     "purchasedescription",
                   "cost",
                  //   "salesdescriptiontranslated",
                    "department",
                    "class",
                    "location",
                    "subsidiary",      
                    // "costcategory",
                    // "created",
                    // "inventorylocation",
                     "parent",
                    // "taxschedule",
                    // "deferredrevenueaccount",
                    // "deferredexpenseaccount"
                ]
            });

            if (params.subsidiaryid) {
              itemSearchObj.filters.push(
                search.createFilter({
                  name: "subsidiary",
                  operator: "anyof",
                  values: [params.subsidiaryid],
                })
              );
            }

            if (params.internalid) {
                itemSearchObj.filters.push(search.createFilter({
                    name: 'internalid',
                    operator: 'anyof',
                    values: [params.internalid]
                }));
            }
            if (params.name) {
                itemSearchObj.filters.push(search.createFilter({
                    name: 'itemid',
                    operator: 'haskeywords',
                    values: [params.name]
                }));
            }
            if (params.type) {
                itemSearchObj.filters.push(search.createFilter({
                    name: 'type',
                    operator: 'anyof',
                    values: [params.type]
                }));
            }
            var searchResultCount = itemSearchObj.runPaged().count;
            var startIndex = params.startIndex || 0;
            var batchSize = params.batchSize || 100;
            var endIndex = parseInt(startIndex) + parseInt(batchSize);
            if (endIndex > searchResultCount) {
              endIndex = searchResultCount;
          }
            var searchResults = itemSearchObj.run().getRange({ start: startIndex, end: endIndex });

            var items = searchResults.map(function (result) {
                return {
                    internalid: result.getValue("internalid"),
                    isinactive: result.getValue("isinactive"),
                    itemname: result.getValue("itemid"),
                    salesdescription: result.getValue("salesdescription"),
                    type: result.getValue("type"),
                    baseprice: result.getValue("baseprice"),
                    subtype: result.getValue("subtype"),
                    fulfillable: result.getValue("isfulfillable"),
                    // expenseaccount: result.getValue("expenseaccount"),
                    // incomeaccount: result.getValue("incomeaccount"),
                     purchasedescription: result.getValue("purchasedescription"),
                  //  // cost: result.getValue("cost"),
                    department: result.getValue("department"),
                    class: result.getValue("class"),
                    location: result.getValue("location"),
                     subsidiary: result.getValue("subsidiary"),
                    // internalid: result.getValue("internalid"),
                    // costcategory: result.getValue("costcategory"),
                    // created: result.getValue("created"),
                    // inventorylocation: result.getValue("inventorylocation"),
                    // parent: result.getValue("parent"),
                    // taxschedule: result.getValue("taxschedule"),
                    // deferredrevenueaccount: result.getValue("deferredrevenueaccount"),
                    // deferredexpenseaccount: result.getValue("deferredexpenseaccount")
                };
            });

            return { items: items, totalRecords: items.length };
        } catch (e) {
            log.debug({
                title: "Error in doGet",
                details: e.message
            });
            return {
                success: false,
                error: e.message
            };
        }
    }

    //Create an item
    function createItem(params) {
        try {
           var itemtype = params.type;
    log.debug("itemtype", itemtype);
    
    var newItem;
    switch (itemtype) {
      case "Service":
        newItem = record.create({
          type: record.Type.SERVICE_ITEM,
          isDynamic: true
        });
        break;
      case "Inventory":
        newItem = record.create({
          type: record.Type.INVENTORY_ITEM,
          isDynamic: true
        });
        break;
      case "OtherCharges":
        newItem = record.create({
          type: record.Type.OTHER_CHARGE_ITEM,
          isDynamic: true
        });
        break;
      default:
        throw new Error("Invalid item type");
    }
            
            // Set the item fields
            if (params.itemname) {
                newItem.setValue('itemid', params.itemname);
            }

            if (params.salesdescription) {
                newItem.setValue('salesdescription', params.salesdescription);
            }
            if (params.baseprice) {
                newItem.setValue('baseprice', params.baseprice);
            }

            if (params.expenseaccount) {
                newItem.setValue('expenseaccount', params.expenseaccount);
            }

            if (params.incomeaccount) {
                newItem.setValue('incomeaccount', params.incomeaccount);
            }

            if (params.purchasedescription) {
                newItem.setValue('purchasedescription', params.purchasedescription);
            }

            if (params.cost) {
                newItem.setValue('cost', params.cost);
            }

            if (params.department) {
                newItem.setValue('department', params.department);
            }

            if (params.class) {
                newItem.setValue('class', params.class);
            }

            if (params.location) {
                newItem.setValue('location', params.location);
            }

            if (params.subsidiary) {
                newItem.setValue('subsidiary', params.subsidiary);
            }

            if (params.costcategory) {
                newItem.setValue('costcategory', params.costcategory);
            }

            if (params.inventorylocation) {
                newItem.setValue('inventorylocation', params.inventorylocation);
            }

            if (params.parent) {
                newItem.setValue('parent', params.parent);
            }

            if (params.taxschedule) {
                newItem.setValue('taxschedule', params.taxschedule);
            }

            if (params.deferredrevenueaccount) {
                newItem.setValue('deferredrevenueaccount', params.deferredrevenueaccount);
            }

            if (params.deferredexpenseaccount) {
                newItem.setValue('deferredexpenseaccount', params.deferredexpenseaccount);
            }

            // Save the item record
            var itemId = newItem.save();

            return itemId;

        } catch (e) {
            log.debug({
                title: 'Error in createItem',
                details: e.message
            });
            return {
                success: false,
                error: e.message
            };
        }
    }


    function doGet(params) {
        try {
            var items = getitems(params);
            return JSON.stringify({
                success: true,
                items: items.items,
                totalRecords: items.totalRecords
            });
        } catch (e) {
            log.debug({
                title: 'Error in doGet',
                details: e.message,
            });
            return {
                success: false,
                error: e.message,
            };
        }
    }

    // Post CAll
    function doPost(params) {
        try {
            log.debug('params', params);
            log.debug('params.type', params.type);
            var itemId = createItem(params);
            log.debug('itemId', itemId);

            if (itemId.success === false) {
                return JSON.stringify({
                    success: false,
                    error: itemId.error
                });
            }

            return JSON.stringify({
                success: true,
                itemId: itemId
            });

        } catch (e) {
            log.error({
                title: 'Error in doPost',
                details: e.message
            });
            return JSON.stringify({
                success: false,
                error: e.message
            });
        }
    }

    function updateItem(params) {
        try {
            var itemid = params.internalid;
        // Check if the customerId is provided
        if (!itemid) {
          throw new Error("Missing 'internalid' parameter.");
        }
        
          
        var itemtype = params.type;

        // Check if the itemtype is provided
        if (!itemtype) {
          throw new Error("Missing 'type' parameter.");
        }
    
        var itemId = params.itemId;
        var itemRecord = record.load({
          type: itemtype, // Use the provided itemtype parameter
          id: itemid,
          isDynamic: true
        });
      
          // Set the item fields
          if (params.itemname) {
            itemRecord.setValue('itemid', params.itemname);
          }
      
          if (params.salesdescription) {
            itemRecord.setValue('salesdescription', params.salesdescription);
          }
      
          if (params.baseprice) {
            itemRecord.setValue('baseprice', params.baseprice);
          }
      
          if (params.expenseaccount) {
            itemRecord.setValue('expenseaccount', params.expenseaccount);
          }
      
          if (params.incomeaccount) {
            itemRecord.setValue('incomeaccount', params.incomeaccount);
          }
      
          if (params.purchasedescription) {
            itemRecord.setValue('purchasedescription', params.purchasedescription);
          }
      
          if (params.cost) {
            itemRecord.setValue('cost', params.cost);
          }
      
          if (params.department) {
            itemRecord.setValue('department', params.department);
          }
      
          if (params.class) {
            itemRecord.setValue('class', params.class);
          }
      
          if (params.location) {
            itemRecord.setValue('location', params.location);
          }
      
          if (params.subsidiary) {
            itemRecord.setValue('subsidiary', params.subsidiary);
          }
      
        //   if (params.costcategory) {
        //     itemRecord.setValue('costcategory', params.costcategory);
        //   }
      
          if (params.inventorylocation) {
            itemRecord.setValue('inventorylocation', params.inventorylocation);
          }
      
          if (params.parent) {
            itemRecord.setValue('parent', params.parent);
          }
      
          if (params.taxschedule) {
            itemRecord.setValue('taxschedule', params.taxschedule);
          }
      
          if (params.deferredrevenueaccount) {
            itemRecord.setValue('deferredrevenueaccount', params.deferredrevenueaccount);
          }
      
          if (params.deferredexpenseaccount) {
            itemRecord.setValue('deferredexpenseaccount', params.deferredexpenseaccount);
          }
      
          // Save the item record
         var itemid=itemRecord.save();
      
          return {
            success: true,
            itemId: itemid
          };
      
        } catch (e) {
          log.error({
            title: 'Error in updateItem',
            details: e.message
          });
          return {
            success: false,
            error: e.message
          };
        }
      }
      
      function doPut(params) {
        try {
          log.debug('params', params);
          log.debug('params.itemId', params.itemId);
      
          var result = updateItem(params);
      
          if (result.success === false) {
            return JSON.stringify({
              success: false,
              error: result.error
            });
          }
      
          return JSON.stringify({
            success: true,
            itemId: result.itemId + " - Item updated successfully."
          });
      
        } catch (e) {
          log.error({
            title: 'Error in doPut',
            details: e.message
          });
          return JSON.stringify({
            success: false,
            error: e.message
          });
        }
      }
      
      

    return {
        get: doGet,
        post: doPost,
        put:doPut
    };
});
