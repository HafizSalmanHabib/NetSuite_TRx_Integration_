/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search'], function (search) {
  
  return {
    get: function (params ) {
      try {
        var employeeData = [];
        
        // Define a search to retrieve employee data
        var employeeSearch = search.create({
          type: search.Type.EMPLOYEE,
          columns: ['entityid', 'firstname', 'lastname','subsidiary'],
          filters:[["isinactive","is","F"]]
        });

        if (params.subsidiaryid) {
          employeeSearch.filters.push(
            search.createFilter({
              name: 'subsidiary',
              operator: 'anyof',
              values: [params.subsidiaryid]
            })
          );
        }
        // Run the search and iterate through the results
        employeeSearch.run().each(function(result) {
          var employeeId = result.id;
          var employeeName = result.getValue('entityid') + ' ' + result.getValue('firstname') + ' ' + result.getValue('lastname');
          var subsidiary=result.getValue('subsidiary');
          var isinactive=result.getText('isinactive');
          // Add employee data to the array
          employeeData.push({
            employeeId: employeeId,
            isinactive:isinactive,
            employeeName: employeeName,
            subsidiary:subsidiary
          });
          log.debug("employeeData",employeeData);
          return true; // Continue processing results
        });
        log.debug("employeeData",employeeData);
        return JSON.stringify(employeeData);
      } catch (e) {
        log.debug({
          title: 'Error in GET request',
          details: e.message
        });
        return {
          success: false,
          error: e.message
        };
      }
    }
  };
});
