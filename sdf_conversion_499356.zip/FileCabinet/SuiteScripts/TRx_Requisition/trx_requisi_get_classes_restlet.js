/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */
define(["N/search", "N/record"], function (search, record) {
  function getClassificationData(params) {
    var classificationSearchObj = search.create({
      type: "classification",
      filters: [["isinactive","is","F"]],
      columns: [
        search.createColumn({ name: "internalid", label: "Internal ID" }),
        search.createColumn({
          name: "name",
          sort: search.Sort.ASC,
          label: "Name",
        }),
        search.createColumn({ name: "subsidiary", label: "Subsidiary" }),
      ],
    });
    
    if (params.subsidiaryid) {
      classificationSearchObj.filters.push(
        search.createFilter({
          name: "subsidiary",
          operator: "anyof",
          values: [params.subsidiaryid],
        })
      );
    }
    
    if (params.internalid) {
      log.debug("internalid", params.internalid);
      classificationSearchObj.filters.push(
        search.createFilter({
          name: "internalid",
          operator: "anyof",
          values: [params.internalid],
        })
      );
    }
    if (params.name) {
      log.debug("name", params.name);
      classificationSearchObj.filters.push(
        search.createFilter({
          name: "name",
          operator: "contains",
          values: [params.name],
        })
      );
    }
  
    var searchResultCount = classificationSearchObj.runPaged().count;
    var startIndex = params.startIndex || 0;
    var batchSize = params.batchSize || 100;
    var endIndex = parseInt(startIndex) + parseInt(batchSize);
  
    var searchResults = classificationSearchObj.run().getRange({
      start: startIndex,
      end: endIndex,
    });
  
    var classifications = [];
  
    searchResults.forEach(function (result) {
      var internalId = result.getValue({
        name: "internalid",
      });
  
      var isinactive = result.getText({
        name: "isinactive",
      });
      var name = result.getValue({
        name: "name",
      });
  
      var subsidiary = result.getValue({
        name: "subsidiary",
      });
  
      classifications.push({
        internalid: internalId,
        isinactive:isinactive,
        name: name,
        subsidiary: subsidiary,
      });
    });
  
    return { data: classifications, totalRecords: classifications.length };
  }
  

  function doGet(params) {
    try {
      var data = getClassificationData(params);
      return JSON.stringify({
        success: true,
        data: data.data,
        totalRecords: data.totalRecords,
      });
    } catch (e) {
      log.error({
        title: "Error in doGet",
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  function createClassification(data) {
    var classificationRecord = record.create({
      type: record.Type.CLASSIFICATION,
    });

    classificationRecord.setValue({
      fieldId: "name",
      value: data.name,
    });

    classificationRecord.setValue({
      fieldId: "subsidiary",
      value: data.subsidiary,
    });

    // Add any additional fields as needed

    var classificationId = classificationRecord.save();

    return { success: true, classificationId: classificationId };
  }

  function doPost(data) {
    try {
      var result = createClassification(data);
      return {
        success: true,
        classId: result.classificationId,
      };
    } catch (e) {
      log.error({
        title: 'Error in doPost',
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }
  function updateClassification(params) {
    // Retrieve the internal ID from the params object
    var classificationId = params.internalId;
  
    // Check if the internalId is provided
    if (!classificationId) {
      throw new Error("Missing 'internalId' parameter.");
    }
  
    var classificationRecord = record.load({
      type: record.Type.CLASSIFICATION,
      id: classificationId,
      isDynamic: true,
    });
  
    // Update the main fields
    if (params.name) {
      classificationRecord.setValue({
        fieldId: "name",
        value: params.name,
      });
    }
    if (params.subsidiary) {
      classificationRecord.setValue({
        fieldId: "subsidiary",
        value: params.subsidiary,
      });
    }
    // Add any additional fields as needed
  
    // Save the updated classification record
    var updatedClassificationId = classificationRecord.save();
  
    return {
      internalId: updatedClassificationId,
      message: "Classification updated successfully",
    };
  }
  
  function doPut(params) {
    try {
      var updatedClassification = updateClassification(params);
      return JSON.stringify({
        success: true,
        classificationId: updatedClassification.internalId,
        message: "Classification updated successfully",
      });
    } catch (e) {
      log.error({
        title: "Error in doPut",
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }
  
  return {
    get: doGet,
    post: doPost,
    put: doPut
  };
});
