/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */
define(["N/search", "N/record"], function (search, record) {
  function getDepartmentData(params) {
    var departmentSearchObj = search.create({
      type: "department",
      filters: [["isinactive","is","F"]],
      columns: [
        search.createColumn({ name: "internalid", label: "Internal ID" }),
        search.createColumn({
          name: "name",
          sort: search.Sort.ASC,
          label: "Name",
        }),
        search.createColumn({ name: "subsidiary", label: "Subsidiary" }),
      ],
    });
    if (params.subsidiaryid) {
      departmentSearchObj.filters.push(
        search.createFilter({
          name: 'subsidiary',
          operator: 'anyof',
          values: [params.subsidiaryid]
        })
      );
    }
    if (params.internalid) {
      departmentSearchObj.filters.push(
        search.createFilter({
          name: 'internalid',
          operator: 'anyof',
          values: [params.internalid]
        })
      );
    }
    if (params.name) {
      departmentSearchObj.filters.push(
        search.createFilter({
          name: 'name',
          operator: 'contains',
          values: [params.name]
        })
      );
    }
    var searchResultCount = departmentSearchObj.runPaged().count;
    var startIndex = params.startIndex || 0;
    var batchSize = params.batchSize || 100;
    var endIndex = parseInt(startIndex) + parseInt(batchSize);
    var searchResults = departmentSearchObj.run().getRange({
      start: startIndex,
      end: endIndex,
    });
  
    var departments = [];
  
    searchResults.forEach(function (result) {
      var internalId = result.getValue({
        name: "internalid",
      });
       var isinactive = result.getText({
        name: "isinactive",
      });
  
      var name = result.getValue({
        name: "name",
      });
  
      var subsidiary = result.getValue({
        name: "subsidiary",
      });
  
      departments.push({
        internalId: internalId,
        isinactive:isinactive,
        name: name,
        subsidiary: subsidiary,
      });
    });
  
    return { data: departments, totalRecords: searchResultCount };
  }
  
  function doGet(params) {
    try {
      
      var data = getDepartmentData(params);
      var response = JSON.stringify({
        success: true,
        data: data.data,
        totalRecords: data.totalRecords,
      });
      return response;
    } catch (e) {
      log.error({
        title: 'Error in doGet',
        details: e.message,
      });
      var errorResponse = {
        success: false,
        error: e.message,
      };
      return JSON.stringify(errorResponse);
    }
  }
  
  

  function createDepartment(data) {
    var departmentRecord = record.create({
      type: record.Type.DEPARTMENT,
    });

    departmentRecord.setValue({
      fieldId: "name",
      value: data.name,
    });

    departmentRecord.setValue({
      fieldId: "subsidiary",
      value: data.subsidiary,
    });

    // Add any additional fields as needed

    var departmentId = departmentRecord.save();

    return { success: true, departmentId: departmentId };
  }

  function doPost(data) {
    try {
      var result = createDepartment(data);
      return {
        success: true,
        departmentId: result.departmentId,
      };
    } catch (e) {
      log.error({
        title: 'Error in doPost',
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  // Update department 
  function updateDepartment(data) {
     // Retrieve the internal ID from the params object
     var departmentId = data.internalid;
  
     // Check if the internalId is provided
     if (!departmentId) {
       throw new Error("Missing 'internalId' parameter.");
     }
    const departmentRecord = record.load({
      type: record.Type.DEPARTMENT,
      id: departmentId
    });
  
    departmentRecord.setValue({
      fieldId: "name",
      value: data.name
    });
  
    departmentRecord.setValue({
      fieldId: "subsidiary",
      value: data.subsidiary
    });
  
    // Update any additional fields as needed
  
    var updatedId=departmentRecord.save();
  
    return {
      internalId: updatedId
    };
  }

  function doPut(params) {
    try {
      var updatedDepartment = updateDepartment(params);
      return {
        Success: true,
        DepartmentId: updatedDepartment.internalId,
        Message: "Department updated successfully",
      };
    } catch (e) {
      log.error({
        title: "Error in doPut",
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  return {
    get: doGet,
    post: doPost,
    put:doPut
  };
});
