/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/record','N/format'], function(search, record,format) {

  /**
   * Retrieves an array of purchase orders based on the provided search criteria.
   * 
   * @param {Object} params - Search criteria object.
   * @param {String} params.vendorId - The internal ID of the vendor to search for.
   * @param {Number} [startIndex=0] - The start index for the search results. Default is 0.
   * @param {Number} [batchSize=100] - The number of search results to return in a batch. Default is 100.
   * 
   * @returns {Array} An array of purchase orders.
   */
  function createPurchaseOrderSearch(params) {
    const poSearch = search.create({
      type: search.Type.PURCHASE_ORDER,
      columns: [
        "internalid",
        "entity",
        "statusref",
        search.createColumn({ name: "address", join: "vendor" }),
        "shipmethod",
        "trandate",
        "closedate",
        "memo",
        "subsidiary",
        "exchangerate",
       // "supervisorapproval",
        "class",
        "department",
        "location",
        "terms",
        "tranid",
        "status",
        "total",
        "amount",
        "shipaddress",
        "shipaddress1",
        "shipaddress2",
        "shipcity",
        "shipcountry",
        "shipstate",
        "shipzip",
        "incoterm",
       // "fob",
        "shipto",
       // "shipaddresslist",
        search.createColumn({ name: "shipaddress", label: "Shipping Address" }),
        search.createColumn({ name: "shipto", label: "Ship To" }),
        search.createColumn({
          name: "address1",
          join: "vendor",
          label: "Address 1"
        }),
        search.createColumn({
          name: "address2",
          join: "vendor",
          label: "Address 2"
        }),
        search.createColumn({
          name: "city",
          join: "vendor",
          label: "City"
        }),
        search.createColumn({
          name: "country",
          join: "vendor",
          label: "Country"
        }),
        search.createColumn({
          name: "state",
          join: "vendor",
          label: "State/Province"
        }),
        search.createColumn({
          name: "zipcode",
          join: "vendor",
          label: "Zip Code"
        })
      ],
      filters: [["mainline", "is", "true"]]
    });
  
    if (params.vendorId) {
      poSearch.filters.push(
        search.createFilter({
          name: "entity",
          operator: "anyof",
          values: [params.vendorId]
        })
      );
    }

    if (params.subsidiaryid) {
      poSearch.filters.push(
        search.createFilter({
          name: "subsidiary",
          operator: "anyof",
          values: [params.subsidiaryid]
        })
      );
    }
    // params.internalid="67775";
    if (params.internalid) {
      poSearch.filters.push(
        search.createFilter({
          name: "internalid",
          operator: "anyof",
          values: [params.internalid]
        })
      );
    }
  
    if (params.ponumber) {
      poSearch.filters.push(
        search.createFilter({
          name: "number",
          operator: "equalto",
          values: [params.ponumber]
        })
      );
    }
  
    return poSearch;
  }
  
  function getPurchaseOrders(params) {
    log.debug("params", params);
    try {
      const poSearch = createPurchaseOrderSearch(params);
      const searchResultCount = poSearch.runPaged().count;
      const startIndex = params.start || 0;
      const batchSize = params.batchSize || 100;
      const endIndex = parseInt(startIndex) + parseInt(batchSize);
      const searchResults = poSearch.run().getRange({
        start: startIndex,
        end: endIndex
      });
  
      const purchaseOrders = searchResults.map(result => {
        return createPurchaseOrderData(result);
      });
  
      return { purchaseOrders, totalRecords: searchResultCount };
    } catch (e) {
      log.debug({
        title: "Error in getPurchaseOrders",
        details: e.message
      });
      return { success: false, error: e.message };
    }
  }
  
  function createPurchaseOrderData(result) {
    try {
      const purchaseOrderId = result.getValue("internalid");
      const purchaseOrderRecord = record.load({
        type: record.Type.PURCHASE_ORDER,
        id: purchaseOrderId,
        isDynamic: true
      });
  
      const items = getItemDetails(purchaseOrderRecord);
      log.debug("items",items);
      const expenses = getExpenseDetails(purchaseOrderRecord);
  
      return {
        internalid: purchaseOrderId,
        ponumber: result.getValue("tranid"),
        vendorname: result.getText("entity"),
        orderstatus: result.getText("statusref"),
        shipmethod: result.getValue("shipmethod"),
        vendoraddress: result.getValue({ name: "address", join: "vendor" }),
        trandate: result.getValue("trandate"),
        closedate: result.getValue("closedate"),
        class: result.getText("class"),
        subsidiary: result.getText("subsidiary"),
        memo: result.getValue("memo"),
        exchangerate: result.getValue("exchangerate"),
        department: result.getText("department"),
        location: result.getText("location"),
        amount: result.getValue("amount"),
        status: result.getText("status"),
        total: result.getValue("total"),
        terms: result.getText("terms"),
        customer: result.getText("shipto"),
        shipaddress: result.getValue("shipaddress"),
        shipaddress1: result.getValue("shipaddress1"),
        shipaddress2: result.getValue("shipaddress2"),
        shipcity: result.getValue("shipcity"),
        // ...remaining properties
        items: items,
        expenses: expenses
      };
    } catch (e) {
      log.debug({
        title: "Error in createPurchaseOrderData",
        details: e.message
      });
      return e.message;
    }
  }
  
  
  function getItemDetails(purchaseOrderRecord) {
    const itemlineCount = purchaseOrderRecord.getLineCount({ sublistId: "item" });
    const items = [];
  log.debug("start Items");
    for (let i = 0; i < itemlineCount; i++) {
      const itemId = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "item",
        line: i
      });
  
      const itemName = purchaseOrderRecord.getSublistText({
        sublistId: "item",
        fieldId: "item",
        line: i
      });
  
      const itemDescription = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "description",
        line: i
      });
  
      const itemClass = purchaseOrderRecord.getSublistText({
        sublistId: "item",
        fieldId: "class",
        line: i
      });
  
      const accounts = purchaseOrderRecord.getSublistText({
        sublistId: "item",
        fieldId: "custcol_accounts",
        line: i
      });
  
      const quantity = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "quantity",
        line: i
      });
  
      const rate = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "rate",
        line: i
      });
  
      const amount = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "amount",
        line: i
      });
      const customer = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "customer",
        line: i
      });
      const department = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "department",
        line: i
      });
      const billed = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "quantitybilled",
        line: i
      });
      const received = purchaseOrderRecord.getSublistValue({
        sublistId: "item",
        fieldId: "quantityreceived",
        line: i
      });

      
      items.push({
        itemId: itemId,
        itemName: itemName,
        itemDescription: itemDescription,
        itemClass: itemClass,
        accounts: accounts,
        quantity: quantity,
        rate: rate,
        amount: amount,
        department:department,
        customer:customer,
        billed:billed,
        received:received
      });
    }
  log.debug("items",items);
    return items;
  }
  
  function getExpenseDetails(purchaseOrderRecord) {
    const expenselineCount = purchaseOrderRecord.getLineCount({
      sublistId: "expense"
    });
    const expenses = [];
  
    for (let i = 0; i < expenselineCount; i++) {
      const account = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "account",
        line: i
      });
  
      const accountDisplay = purchaseOrderRecord.getSublistText({
        sublistId: "expense",
        fieldId: "account",
        line: i
      });
  
      const amount = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "amount",
        line: i
      });
  
      const billableEnabled = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "isbillable",
        line: i
      });
  
      const category = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "category",
        line: i
      });
  
      const categoryDisplay = purchaseOrderRecord.getSublistText({
        sublistId: "expense",
        fieldId: "category",
        line: i
      });
  
      const categoryExpAccount = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "categoryexpaccount",
        line: i
      });
  
      const customer = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "customer",
        line: i
      });
  
      const customerDisplay = purchaseOrderRecord.getSublistText({
        sublistId: "expense",
        fieldId: "customer",
        line: i
      });
  
      const isBillable = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "isbillable",
        line: i
      });
  
      const isClosed = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "isclosed",
        line: i
      });
  
      const line = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "line",
        line: i
      });
  
      const linked = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "linked",
        line: i
      });
  
      const memo = purchaseOrderRecord.getSublistValue({
        sublistId: "expense",
        fieldId: "memo",
        line: i
      });
  
      expenses.push({
        account: account,
        accountDisplay: accountDisplay,
        amount: amount,
        billableEnabled: billableEnabled,
        category: category,
        categoryDisplay: categoryDisplay,
        categoryExpAccount: categoryExpAccount,
        customer: customer,
        customerDisplay: customerDisplay,
        isBillable: isBillable,
        isClosed: isClosed,
        line: line,
        linked: linked,
        memo: memo
      });
    }
  
    return expenses;
  }
  

/**
 * Create a Purchase Order in NetSuite.
 * @param {Object} params - Parameters for creating the Purchase Order.
 * @returns {number} - The ID of the created Purchase Order.
 */
function createPurchaseOrder(params) {
  try {
    var purchaseRecord = record.create({
      type: record.Type.PURCHASE_ORDER,
      isDynamic: true
    });

    
      purchaseRecord.setValue({
        fieldId: 'entity',
        value: params.vendorid
      });
    

    if (params.memo) {
      purchaseRecord.setValue({
        fieldId: 'memo',
        value: params.memo
      });
    }

    if (params.classid) {
      purchaseRecord.setValue({
        fieldId: 'class',
        value: params.classid
      });
    }
    if (params.duedate) {
      var formatduedateDate = format.parse({ value: params.duedate, type: format.Type.DATE });
      purchaseRecord.setValue({
        fieldId: 'duedate',
        value: formatduedateDate
      });
    }
    
        
    if (params.trandate) {
      var formattedDate = format.parse({ value: params.trandate, type: format.Type.DATE });
      purchaseRecord.setValue({
        fieldId: 'trandate',
        value: formattedDate
      });
    } 

    if (params.locationid) {
      purchaseRecord.setValue({
        fieldId: 'location',
        value: params.locationid
      });
    }
    if (params.departmentid) {
      purchaseRecord.setValue({
        fieldId: 'department',
        value: params.departmentid
      });
    } 

    if (params.termsid) {
      purchaseRecord.setValue({
        fieldId: 'terms',
        value: params.termsid
      });
    }
    if (params.incotermid) {
      purchaseRecord.setValue({
        fieldId: 'terms',
        value: params.incotermid
      });
    }
    if (params.employeeid) {
      purchaseRecord.setValue({
        fieldId: 'employee',
        value: params.employeeid
      });
    }
    if (params.ponumber) {
      log.debug("set po Number");
      purchaseRecord.setValue({
        fieldId: 'tranid',
        value: params.ponumber
      });
    }
    if (params.currencyid) {
      log.debug("set po Number");
      purchaseRecord.setValue({
        fieldId: 'currency',
        value: params.currencyid
      });
    }
    if (params.intercotransactionid) {
      
      purchaseRecord.setValue({
        fieldId: 'intercotransaction',
        value: params.intercotransactionid
      });
    }
    if (params.exchangerate) {
      
      purchaseRecord.setValue({
        fieldId: 'exchangerate',
        value: params.exchangerate
      });
    }
     
    if (params.shipdate) {
      formattedDate = format.parse({ value: params.shipdate, type: format.Type.DATE });
      purchaseRecord.setValue({
        fieldId: 'shipdate',
        value: formattedDate
      });
    }
    purchaseRecord.setValue({
      fieldId: 'shipmethod',
      value: params.shipmethod || ' '
    });
    if (params.trackingnumbers) {
      
      purchaseRecord.setValue({
        fieldId: 'trackingnumbers',
        value: params.trackingnumbers
      });
    }
    if (params.shipaddresslist) {
      
      purchaseRecord.setValue({
        fieldId: 'shipaddresslist',
        value: params.shipaddresslist
      });
    }
    //shipto== cistomer
    if (params.shipto) {
      
      purchaseRecord.setValue({
        fieldId: 'shipto',
        value: params.shipto
      });
    } 
    

    if (params.items && params.items.length > 0) {
      for (var i = 0; i < params.items.length; i++) {
        var itemdata = params.items[i];
        purchaseRecord.selectNewLine({
          sublistId: 'item'
        });
        purchaseRecord.setCurrentSublistValue({
          sublistId: 'item',
          fieldId: 'item',
          value: itemdata.itemid
        });
        purchaseRecord.setCurrentSublistValue({
          sublistId: 'item',
          fieldId: 'quantity',
          value: itemdata.quantity
        });
        purchaseRecord.setCurrentSublistValue({
          sublistId: 'item',
          fieldId: 'rate',
          value: itemdata.rate
        });
        if (itemdata.amount) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'amount',
            value: itemdata.amount
          });
        }
        if (itemdata.customerid) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'customer',
            value: itemdata.customerid
          });
        }
        if (itemdata.departmentid) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'department',
            value: itemdata.departmentid
          });
        }
        if (itemdata.classid) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'class',
            value: itemdata.classid
          });
        }
        if (itemdata.locationid) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'location',
            value: itemdata.locationid
          });
        }
        if (itemdata.description) {
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'description',
            value: itemdata.description
          });
        }
        if (itemdata.expectedreceiptdate) {
         var formattedDate = format.parse({ value: itemdata.expectedreceiptdate, type: format.Type.DATE });
          purchaseRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'expectedreceiptdate',
            value: formattedDate
          });
        }
        purchaseRecord.commitLine({
          sublistId: 'item'
        });
      }
    }

    // Add Expenses To PurchaseRecord
    addExpensesToPurchaseRecord(purchaseRecord, params.expenses);

    var poId = purchaseRecord.save({
      enableSourcing: true,
      ignoreMandatoryFields: false
    });
    log.debug("params.attachment.length",params.attachment);
    log.debug("params.attachment.length",params.attachment.length);
    // ... (your existing code)

if (params.attachment && params.attachment.length > 0) {
  for (var i = 0; i < params.attachment.length; i++) {
      var attachmentdata = params.attachment[i];
      
      var attachmentRecord = record.create({
          type: 'customrecord_trx_attachments',
          isDynamic: true
      });

      attachmentRecord.setValue({
          fieldId: 'name',
          value: attachmentdata.filename
      });

      attachmentRecord.setValue({
          fieldId: 'custrecord_trx_attachments',
          value: attachmentdata.fileurl
      });

      // Associate the attachment record with the purchase order
      attachmentRecord.setValue({
          fieldId: 'custrecord_trx_po_number',
          value: poId 
      });
     
      var attachmentId = attachmentRecord.save();
      log.debug("attachmentId",attachmentId);
  }
}

// ... (continue with your existing code)


    return poId;
  } catch (err) {
    log.debug({
      title: 'Error createPurchaseOrder',
      details: err.message
    });
    throw err;
  }
}




function addExpensesToPurchaseRecord(purchaseRecord, expenses) {
  try{
  if (expenses && expenses.length > 0) {
    var expenselineCount = expenses.length;

    for (var i = 0; i < expenses.length; i++) {
      var expense = expenses[i];
      purchaseRecord.selectNewLine({ sublistId: 'expense' });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'account', value: expense.account });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'amount', value: expense.amount });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'category', value: expense.category });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'categoryexpaccount', value: expense.categoryExpAccount });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'memo', value: expense.memo });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'isbillable', value: expense.billableEnabled });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'isclosed', value: expense.isClosed });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'customer', value: expense.customer });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'class', value: expense.class });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'department', value: expense.department });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'location', value: expense.location });
      // Set other expense-related fields as needed
      // ...
      purchaseRecord.commitLine({ sublistId: 'expense' });
    }
  }
}
  catch (e) {
    log.debug({
      title: 'Error in addItemsToPurchaseRecord',
      details: e.message
    });
    
    var errorResponse = {
      success: false,
      error: e.message
    };
    
    return JSON.stringify(errorResponse);
  }
}



  // Get Call
  function doGet(params) {
    try {
      log.debug("params", params);
      var result = getPurchaseOrders(params);
     // log.debug("purchaseOrder", purchaseOrder);
      
      var response = {
        success: true,
        purchaseOrders: result.purchaseOrders,
        totalPurchaseOrders:result.totalrecords
      };
      
      return JSON.stringify(response);
    } catch (e) {
      log.debug({
        title: 'Error in doGet',
        details: e.message
      });
      
      var errorResponse = {
        success: false,
        error: e.message
      };
      
      return JSON.stringify(errorResponse);
    }
  }
  

  // Post Call

  function doPost(params) {
    try {
      log.debug("doPost");
      var poId = createPurchaseOrder(params);
      log.debug("doPost");
      return {
        success: true,
        poId: poId
      };
    } catch (e) {
      log.error({
        title: 'Error in doPost',
        details: e.message
      });
      return {
        success: false,
        error: e.message
      };
    }
  }
  
// Function to update the Purchase Order
function updatePurchaseOrder(poId, params) {
  try {
    var purchaseRecord = record.load({
      type: record.Type.PURCHASE_ORDER,
      id: poId,
      isDynamic: true
    });

    log.debug("start memo");

    var orderStatus = purchaseRecord.getText({ fieldId: 'statusref' });

    // Update the memo field if it exists in the parameters
    if (orderStatus !== 'Fully Billed' && orderStatus !== 'Partially Received') {
      if(params.vendorname ){
      purchaseRecord.setText({
        fieldId: 'entity',
        text: params.vendorname 
      });
    }
    if(params.trandate ){
      var formattedDate = format.parse({
        value: params.trandate,
        type: format.Type.DATE
      });

      purchaseRecord.setValue({
        fieldId: 'trandate',
        value: formattedDate
      });
    }
      if(params.memo ){
      purchaseRecord.setValue({
        fieldId: 'memo',
        value: params.memo 
      });
      }

    log.debug("params.subsidiary", params.subsidiary);

    if (params.subsidiary) {
      throw new Error("Subsidiary is not an editable field.");
    }
    if (params.ponumber) {
      throw new Error("Ponumber is not an editable field.");
    }

    purchaseRecord.setText({
      fieldId: 'location',
      text: params.location || " "
    });

    purchaseRecord.setValue({
      fieldId: 'exchangerate',
      value: params.exchangerate || " "
    });

    purchaseRecord.setValue({
      fieldId: 'shipmethod',
      value: params.shipmethod || ' '
    });

    purchaseRecord.setValue({
      fieldId: 'shipto',
      value: params.shiptocustomer || ' '
    });

    // Update the item-related fields if they exist in the parameters
    if (params.items && params.items.length > 0) {
      var items = params.items;
      updatteItemsToPurchaseRecord(purchaseRecord, items);
    }

    // Update the expense-related fields if they exist in the parameters
    if (params.expenses && params.expenses.length > 0) {
      var expenses = params.expenses;
      addExpensesToPurchaseRecord(purchaseRecord, expenses);
    }

    // Save the updated purchase order
    var updatedPoId = purchaseRecord.save({ ignoreMandatoryFields: true });
  }
    return {
      success: true,
      updatedPoId: updatedPoId
    };
  } catch (err) {
    log.debug({
      title: 'Error in updatePurchaseOrder',
      details: err.message
    });
    return {
      success: false,
      error: err.message
    };
  }
}

function updatteItemsToPurchaseRecord(purchaseRecord, items) {
  try{
  var lineCount = purchaseRecord.getLineCount({ sublistId: 'item' });

  // Remove existing item lines
  for (var i = lineCount - 1; i >= 0; i--) {
    purchaseRecord.removeLine({ sublistId: 'item', line: i });
  }
   
  // Add new item lines
  for (var i = 0; i < items.length; i++) {
    purchaseRecord.selectNewLine({ sublistId: 'item' });
    var itemArray = items[i];
    
      purchaseRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: itemArray.itemId });
     /// purchaseRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'description', value: item.itemDescription });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'quantity', value: itemArray.quantity });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: itemArray.rate  });
      purchaseRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'amount', value: itemArray.amount });
    // Set other item-related fields as needed
    // ...
    purchaseRecord.commitLine({ sublistId: 'item' });
  }
}
catch (e) {
  log.debug({
    title: 'Error in updatteItemsToPurchaseRecord',
    details: e.message
  });

  return JSON.stringify({
    success: false,
    error: e.message
  });
}

}

function addExpensesToPurchaseRecord(purchaseRecord, expenses) {
  try{
  var lineCount = purchaseRecord.getLineCount({ sublistId: 'expense' });

  // Remove existing expense lines
  for (var i = lineCount - 1; i >= 0; i--) {
    purchaseRecord.removeLine({ sublistId: 'expense', line: i });
  }

  // Add new expense lines
  for (var i = 0; i < expenses.length; i++) {
    var expense = expenses[i];
    purchaseRecord.selectNewLine({ sublistId: 'expense' });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'account', value: expense.account });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'amount', value: expense.amount });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'category', value: expense.category });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'categoryexpaccount', value: expense.categoryExpAccount });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'memo', value: expense.memo });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'isbillable', value: expense.billableEnabled });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'isclosed', value: expense.isClosed });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'customer', value: expense.customer });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'class', value: expense.class });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'department', value: expense.department });
    purchaseRecord.setCurrentSublistValue({ sublistId: 'expense', fieldId: 'location', value: expense.location });
    // Set other expense-related fields as needed
    // ...
    purchaseRecord.commitLine({ sublistId: 'expense' });
  }
}
  catch (e) {
    log.debug({
      title: 'Error in updatteItemsToPurchaseRecord',
      details: e.message
    });
  
    return JSON.stringify({
      success: false,
      error: e.message
    });
  }
}

function doPut(params) {
  try {
    var poId = params.internalid; // Assuming the purchase order ID is provided in the request parameters

    if (!poId) {
      throw new Error("Missing 'internalid' parameter.");
    }

    var result = updatePurchaseOrder(poId, params);

    if (!result.success) {
      return JSON.stringify({
        success: false,
        error: result.error
      });
    }

    return JSON.stringify({
      success: true,
      updatedPoId: 'Purchase Order updated successfully. Updated PO ID: ' + result.updatedPoId
    });

  } catch (e) {
    log.error({
      title: 'Error in doPut',
      details: e.message
    });

    return JSON.stringify({
      success: false,
      error: e.message
    });
  }
}
  
  return {
    get: doGet,
    post: doPost,
    put:doPut
  };
});
