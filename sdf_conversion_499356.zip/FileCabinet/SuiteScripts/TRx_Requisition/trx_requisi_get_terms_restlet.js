/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */
define(["N/search", "N/record"], function (search, record) {
  function getTermData(params) {
    var termSearchObj = search.create({
      type: "term",
      filters: [["isinactive","is","F"]],
      columns: [
        search.createColumn({
          name: "name",
          sort: search.Sort.ASC,
          label: "Name",
        }),
        search.createColumn({name: "internalid", label: "Internal ID"}),
        search.createColumn({ name: "discountpercent", label: "% Discount" }),
        search.createColumn({ name: "preferred", label: "Preferred" }),
        search.createColumn({ name: "daysuntilnetdue", label: "Days Till Net Due" }),
        search.createColumn({ name: "daydiscountexpires", label: "Day Discount Expires" }),
        search.createColumn({ name: "dayofmonthnetdue", label: "Day of Month Net Due" }),
        search.createColumn({ name: "daysuntilexpiry", label: "Days Till Discount Expires" }),
        search.createColumn({ name: "duenextmonthifwithindays", label: "Due Next Month if Within Days" }),
        'isinactive'
      ],
    });

    var searchResultCount = termSearchObj.runPaged().count;
    var startIndex = params.startIndex || 0;
    var batchSize = params.batchSize || 100;
    var endIndex = parseInt(startIndex) + parseInt(batchSize);
    var searchResults = termSearchObj.run().getRange({
      start: startIndex,
      end: endIndex,
    });

    var terms = [];

    searchResults.forEach(function (result) {
        var internalid = result.getValue({
            name: "internalid",
          });

      var isinactive = result.getText({
        name: "isinactive",
      });
      var name = result.getValue({
        name: "name",
      });

      var discountPercent = result.getValue({
        name: "discountpercent",
      });

      var preferred = result.getValue({
        name: "preferred",
      });

      var daysUntilNetDue = result.getValue({
        name: "daysuntilnetdue",
      });

      var dayDiscountExpires = result.getValue({
        name: "daydiscountexpires",
      });

      var dayOfMonthNetDue = result.getValue({
        name: "dayofmonthnetdue",
      });

      var daysUntilExpiry = result.getValue({
        name: "daysuntilexpiry",
      });

      var dueNextMonthIfWithinDays = result.getValue({
        name: "duenextmonthifwithindays",
      });

      terms.push({
        internalid:internalid,
        name: name,
        discountPercent: discountPercent,
        preferred: preferred,
        daysUntilNetDue: daysUntilNetDue,
        dayDiscountExpires: dayDiscountExpires,
        dayOfMonthNetDue: dayOfMonthNetDue,
        daysUntilExpiry: daysUntilExpiry,
        dueNextMonthIfWithinDays: dueNextMonthIfWithinDays,
        isinactive:isinactive
      });
    });

    return { data: terms, totalRecords: searchResultCount };
  }

  function doGet(params) {
    try {
      var data = getTermData(params);
      return JSON.stringify({
        success: true,
        terms: data.data,
        totalRecords: data.totalRecords,
      });
    } catch (e) {
      log.error({
        title: 'Error in doGet',
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  function createTerm(data) {
    var termRecord = record.create({
      type: record.Type.TERM,
    });

    termRecord.setValue({
      fieldId: "name",
      value: data.name,
    });

    termRecord.setValue({
      fieldId: "discountpercent",
      value: data.discountPercent,
    });

    termRecord.setValue({
      fieldId: "preferred",
      value: data.preferred,
    });

    termRecord.setValue({
      fieldId: "daysuntilnetdue",
      value: data.daysUntilNetDue,
    });

    termRecord.setValue({
      fieldId: "daydiscountexpires",
      value: data.dayDiscountExpires,
    });

    termRecord.setValue({
      fieldId: "dayofmonthnetdue",
      value: data.dayOfMonthNetDue,
    });

    termRecord.setValue({
      fieldId: "daysuntilexpiry",
      value: data.daysUntilExpiry,
    });

    termRecord.setValue({
      fieldId: "duenextmonthifwithindays",
      value: data.dueNextMonthIfWithinDays,
    });

    // Add any additional fields as needed

    var termId = termRecord.save();

    return { success: true, termId: termId };
  }

  function doPost(data) {
    try {
      var result = createTerm(data);
      return {
        success: true,
        termId: result.termId,
      };
    } catch (e) {
      log.error({
        title: 'Error in doPost',
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  //Update the terms 
  function updateTerm(data) {
    // Retrieve the internal ID from the params object
    var termsId = data.internalid;
  
    // Check if the internalId is provided
    if (!termsId) {
      throw new Error("Missing 'internalId' parameter.");
    }
    const termRecord = record.load({
      type: record.Type.TERM,
      id: termsId
    });
  
    termRecord.setValue({
      fieldId: "name",
      value: data.name
    });
  
    termRecord.setValue({
      fieldId: "discountpercent",
      value: data.discountPercent
    });
  
    termRecord.setValue({
      fieldId: "preferred",
      value: data.preferred
    });
  
    termRecord.setValue({
      fieldId: "daysuntilnetdue",
      value: data.daysUntilNetDue
    });
  
    termRecord.setValue({
      fieldId: "daydiscountexpires",
      value: data.dayDiscountExpires
    });
  
    termRecord.setValue({
      fieldId: "dayofmonthnetdue",
      value: data.dayOfMonthNetDue
    });
  
    termRecord.setValue({
      fieldId: "daysuntilexpiry",
      value: data.daysUntilExpiry
    });
  
    termRecord.setValue({
      fieldId: "duenextmonthifwithindays",
      value: data.dueNextMonthIfWithinDays
    });
  
    // Update any additional fields as needed
  
   var termsId= termRecord.save();
  
    return termsId;
  }
  
  function doPut(params) {
    try {
      const result = updateTerm(params);
      return {
        success: true,
        termId: result,
        message: "Term updated successfully"
      };
    } catch (e) {
      log.error({
        title: "Error in doPut",
        details: e.message
      });
      return {
        success: false,
        error: e.message
      };
    }
  }
  
  return {
    get: doGet,
    post: doPost,
    put:doPut
  };
});
