/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/log'], function(search, log) {
   
    function getCustomerAddresses(internalId) {
       // Create a customer search object
       var customerSearchObj = search.create({
          type: 'customer',
          filters: [
             ['internalid', 'anyof', internalId]
          ],
          columns: [
             'internalid',
             'addresslabel',
             'addressee',
             'address',
            'isinactive'
          ]
       });
 
       // Run the customer search
       var searchResults = [];
       customerSearchObj.run().each(function(result) {
          // Process each search result and build the response data
          var resultData = {
              
                isinactive: result.getValue('isinactive'),
             internalId: result.getValue('internalid'),
             addresslabel: result.getValue('addresslabel'),
             address: result.getValue('address')
          };
          searchResults.push(resultData);
          return true; // Continue processing remaining results
       });
 
       return searchResults;
    }
 
    function doGet(params) {
       try {
          // Parse input parameters
          var internalId = params.internalId;
 
          if (!internalId) {
             return JSON.stringify({
                success: false,
                error: 'Missing internalId parameter'
             });
          }
 
          // Get customer addresses
          var addresses = getCustomerAddresses(internalId);
 
          return JSON.stringify({
             success: true,
             results: addresses
          });
       } catch (error) {
          log.error('Error in RESTlet', error);
          return JSON.stringify({
             success: false,
             error: error.message
          });
       }
    }
 
    return {
       get: doGet
    };
 });
 