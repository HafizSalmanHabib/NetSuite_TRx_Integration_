/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/crypto', 'N/record', 'N/ui/serverWidget', 'N/url', 'N/runtime'], function (crypto, record, serverWidget, url, runtime) {
  /**
   * It removes the edit button and prevents editing.
   *
   * @param {Object} context - The SuiteScript context object.
   * @returns {void}
   */
  function beforeLoad(context) {
    try {
         var rec = context.newRecord;
      var form = context.form;
        var record = context.newRecord;
        var accountId = runtime.accountId; // Get the dynamic account ID
        var indexOfUnderscore = accountId.indexOf('_');
        var updatedAccoId = accountId; // Initialize with the original account ID
      
        if (indexOfUnderscore !== -1) {
          // If underscores are found, replace them with hyphens (-)
          updatedAccoId = accountId.split('_').join('-');
        }
      
        // URL values for each hyperlink with the dynamic account ID
        var urlValue1 = 'https://qaerequisition.e-bizsoft.net/Document/HowToIntegrateNetSuite.pdf';
        var urlValue2 = 'https://' + updatedAccoId + '.app.netsuite.com/app/setup/useraccesstoken.nl';
        var urlValue3 = 'https://' + updatedAccoId + '.app.netsuite.com/app/common/integration/integrapp.nl';
        var trxLink = 'https://qaerequisition.e-bizsoft.net/login.aspx';
    // Inline HTML for each hyperlink
    var linkHtml1 = '<div style="padding: 10px; border: 0px solid #ddd; width: 100%; font-size: 12px; color: red;">' +
      '<a href="' + urlValue1 + '" target="_blank">E-REQUISITION MANUAL</a>' +
      '</div>';

    var linkHtml2 = '<div style="padding: 10px; border: 0px solid #ddd; width: 100%; font-size: 12px; color: red;">' +
      '<a href="' + urlValue2 + '" target="_blank">ACCESS TOKEN RECORD</a>' +
      '</div>';

    var linkHtml3 = '<div style="padding: 10px; border: 0px solid #ddd; width: 100%; font-size: 12px; color: red;">' +
      '<a href="' + urlValue3 + '" target="_blank">INTEGRATION RECORD</a>' +
      '</div>';

    var linkHtml4 = '<div style="padding: 10px; border: 0px solid #ddd; width: 100%; font-size: 12px; color: red;">' +
      '<a href="' + trxLink + '" target="_blank">E-REQUISITION LINK</a>' +
      '</div>';

    // Set the default values for each inline HTML field
    form.getField({ id: 'custrecord_requisition_manual' }).defaultValue = linkHtml1;
    form.getField({ id: 'custrecord_trx_link' }).defaultValue = linkHtml4;

    // Check if the record is in the 'Create' mode and set the default values for specific fields
    if (context.type === context.UserEventType.CREATE) {
      form.getField({ id: 'custrecord_access_token_record' }).defaultValue = linkHtml2;
      form.getField({ id: 'custrecord_integration_record' }).defaultValue = linkHtml3;
    }
        
        
      if (context.type === 'view') {
        form.removeButton({id: 'edit'});
        form.removeButton({id: 'print'});
        log.debug("End beforeLoad");
      }

      // Get the URL of a Restlet using the helper function
      var scriptId = 'customscript_get_url_of_trx_restlet';
      var deploymentId = 'customdeploy_get_url_of_trx_restlet';
      var urlRerlettahtCotqntallUrl = getRestletURL(scriptId, deploymentId);
      log.debug("urlRerlettahtCotqntallUrl", urlRerlettahtCotqntallUrl);

      // Set the Restlet URL in a custom field on the record
      rec.setValue({ fieldId: 'custrecord_trx_requisi_base_url', value: urlRerlettahtCotqntallUrl });
    } catch (error) {
      log.error('Error in beforeLoad: ' + error.message);
    }
  }

  function beforeSubmit(context) {
    try {
      if (context.type === context.UserEventType.CREATE || context.type === context.UserEventType.EDIT) {
        var newRecord = context.newRecord;

        var fieldsToHash = [
          'custrecord_erequisition__user_pass',
          'custrecord_consumer_key',
          'custrecord_consumer_secret',
          'custrecord_access_token',
          'custrecord_token_secret'
        ];

        fieldsToHash.forEach(function (fieldId) {
          var fieldValue = newRecord.getValue({ fieldId: fieldId });
          if (fieldValue) {
            try {
              var hashedValue = hashValue(fieldValue);
              newRecord.setValue({ fieldId: fieldId, value: hashedValue });
            } catch (e) {
              log.error({
                title: 'Error hashing value',
                details: e
              });
            }
          }
        });
      }
    } catch (error) {
      log.error('Error in beforeSubmit: ' + error.message);
    }
  }

  function hashValue(value) {
    try {
      // Convert the value to a string if it's not already
      var stringValue = value.toString();

      // Use the SHA-256 hashing algorithm
      var hash = crypto.createHash({
        algorithm: crypto.HashAlg.SHA256
      });

      hash.update({
        input: stringValue,
        encoding: crypto.Encoding.UTF_8
      });

      // Retrieve the hashed value using the 'hex' property
      var hashedValue = hash.digest({
        outputEncoding: crypto.Encoding.HEX
      });

      return hashedValue;
    } catch (error) {
      log.error('Error in hashValue: ' + error.message);
    }
  }

  function getRestletURL(scriptId, deploymentId) {
    var scriptUrl = url.resolveScript({
      scriptId: scriptId,
      deploymentId: deploymentId,
    });
    return scriptUrl;
  }

  return {
    beforeSubmit: beforeSubmit,
    beforeLoad: beforeLoad
  };

});
