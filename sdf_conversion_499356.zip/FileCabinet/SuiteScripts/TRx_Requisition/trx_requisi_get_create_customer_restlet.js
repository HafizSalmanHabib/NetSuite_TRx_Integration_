/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/record'], function (search, record) {

  /**
   * Returns an array of vendor objects with details and addresses based on the provided search criteria.
   * 
   * @param {Object} params - Search criteria object.
   * @param {String} params.name - The name of the customer to search for.
   * @param {Number} [startIndex=0] - The start index for the search results. Default is 0.
   * @param {Number} [batchSize=100] - The number of search results to return in a batch. Default is 100.
   * 
   * @returns {Array} An array of vendor objects.
   */
  function getCustomer(params) {
    log.debug("params", params);
    try {
      const customerSearch = createCustomerSearch(params);
      const searchResults = runCustomerSearch(customerSearch, params);
      const totalCustomer = customerSearch.runPaged().count;
      const customer = convertSearchResults(searchResults);
  
      return { customer, totalCustomer };
    } catch (err) {
      log.debug({
        title: 'Error getCustomer',
        details: err.message
      });
    }
  }
  
  function createCustomerSearch(params) {
    var sublistId = params.subsidiaryid;
    const customerSearch = search.create({
      type: search.Type.CUSTOMER,
      columns: [
        search.createColumn({ name: "entityid", sort: search.Sort.ASC }),
        "firstname",
        "middlename",
        "lastname",
        "isperson",
        "email",
        "internalid",
        "phone",
        "subsidiary",
        search.createColumn({
          name: "internalid",
          join: "mseSubsidiary",
          label: "Internal ID"
       }),
        "url",
        "shipaddress",
        "shipcity",
        "shipcountry",
        "shipzip",
        "shipstate",
        "shipattention",
        "shippingcarrier",
        "billaddress",
        "billcity",
        "billcountry",
        "billzipcode",
        "billstate",
        "billattention",
        "companyname",
        "fax"
      ],
      filters: [["msesubsidiary.internalid","anyof",sublistId], "AND", 
      ["isinactive","is","F"]]
    });
  
    if (params.name) {
      customerSearch.filters.push(
        search.createFilter({
          name: 'entityid',
          operator: 'haskeywords',
          values: [params.name]
        })
      );
    }
    if (params.subsidiaryid) {
      customerSearch.filters.push(
        search.createFilter({
          name: 'subsidiary',
          operator: 'anyof',
          values: [params.subsidiaryid]
        })
      );
    
    }

    if (params.internalid) {
      customerSearch.filters.push(
        search.createFilter({
          name: 'internalid',
          operator: 'anyof',
          values: [params.internalid]
        })
      );
      log.debug("internalid ", params.internalid);
    }
  
    return customerSearch;
  }
  
  function runCustomerSearch(customerSearch, params) {
    const startIndex = params.start || 0;
    const batchSize = params.batchSize || 100;
    const endIndex = parseInt(startIndex) + parseInt(batchSize);
    return customerSearch.run().getRange({ start: startIndex, end: endIndex });
  }
  
  function convertSearchResults(searchResults) {
    return searchResults.map(result => {
      return {
        internalid: result.getValue('internalid'),
        isinactive: result.getValue('isinactive'),
        firstname: result.getValue('firstname'),
        middlename: result.getValue('middlename'),
        lastname: result.getValue('lastname'),
        isperson: result.getValue('isperson'),
        name: result.getValue('entityid'),
        email: result.getValue('email'),
        phone: result.getValue('phone'),
        primarySubsid: result.getValue('subsidiary'),
        primarySubsidName: result.getText('subsidiary'),
        subsidiary: result.getValue({ name: "internalid",join: "mseSubsidiary",}),
        website: result.getValue('url'),
        companyname: result.getValue('companyname'),
        fax: result.getValue('fax'),
        shipaddress: result.getValue('shipaddress'),
        shipcity: result.getValue('shipcity'),
        shipcountry: result.getText('shipcountry'),
        shipzip: result.getValue('shipzip'),
        shipattention: result.getValue('shipattention'),
        shippingcarrier: result.getText('shippingcarrier'),
        shipstate: result.getValue('shipstate'),
        billaddress: result.getValue('billaddress'),
        billcity: result.getValue('billcity'),
        billcountry: result.getText('billcountry'),
        billzipcode: result.getValue('billzipcode'),
        billstate: result.getText('billstate'),
        billattention: result.getValue('billattention')
      };
    });
  }
  


  // Create customer code
  function createCustomer(params) {
    try {
      log.debug("Start");
      var customerRecord = record.create({
        type: 'customer',
        isDynamic: true
      });

      if (params.isperson) {
        customerRecord.setValue({
          fieldId: 'isperson',
          value: 'T'
        });
    
        customerRecord.setValue({
          fieldId: 'firstname',
          value: params.firstname
        });
    
        customerRecord.setValue({
          fieldId: 'middlename',
          value: params.middlename
        });
    
        customerRecord.setValue({
          fieldId: 'lastname',
          value: params.lastname
        });
      } else {
        customerRecord.setValue({
          fieldId: 'companyname',
          value: params.name
        });
      }
       if(params.email){
      if ( isValidEmail(params.email)) {
        customerRecord.setValue({
          fieldId: 'email',
          value: params.email
        });
      } else {
        throw new Error("Invalid email format.");
      }
    }

      if (params.website) {
        if (!isValidWebsite(params.website)) {
          throw new Error("Invalid website format.");
        }

        customerRecord.setValue({
          fieldId: 'url',
          value: params.website
        });
      }


      if (params.phone) {
        if (params.phone.length >= 7) {
          customerRecord.setValue({
            fieldId: 'phone',
            value: params.phone
          });
        } else {
          throw new Error("Phone number should have seven digits or more.");
        }
      }

      if (params.subsidiary) {
        customerRecord.setValue({
          fieldId: 'subsidiary',
          value: params.subsidiary
        });
      }
      log.debug("addressbook", params.addressbook.billingAddress);
      // Set the customer's billing address
      // Update the billing address
      if (params.addressbook) {
        var addressArray = params.addressbook;
        log.debug("addressArray",addressArray);
        updateAddressBook(customerRecord, addressArray);

      }
      var customerId = customerRecord.save();
      return customerId;
    } catch (err) {
      log.debug({
        title: 'Error createCustomer',
        details: err.message
      });
      throw err; // rethrow the error to handle it in the calling function
    }
  }
    // Validate Email
    function isValidEmail(email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }

  // Get CAll
  function doGet(params) {
    try { 
      log.debug("params subsidiaryid", params.subsidiaryid);
      var sublistId = params.subsidiaryid;
      if (!sublistId) {
        var errorCode = "SUBSIDIARY_ID_MISSING"; // Define your error code here
        var errorMessage = "Subsidiary id is missing.";
        var error = {
          code: errorCode,
          message: errorMessage
        };
        throw error;
      }
      var customer = getCustomer(params);
      return JSON.stringify({
        success: true,
        customer: customer.customer,
        totalCustomer: customer.totalCustomer
      });
    } catch (err) {
      log.debug({
        title: 'Error doGet',
        details: err.message
      });
      
      return JSON.stringify({
        error: {
          code: err.code, // Include the error code in the response
          message: err.message
        }
      });
    }
  }
  
  // Post CAll
  function doPost(params) {
    try {
      var customerId = createCustomer(params);
      log.debug("customerId", customerId);
      return JSON.stringify({
        success: true,
        customerId: customerId
      });
    } catch (e) {
      log.error("Error in doPost", e);
      return JSON.stringify({
        success: false,
        error: e.message || "An error occurred."
      });
    }
  }

     //Update Record 
     function doPut(params) {
      try {
        var customerId = getCustomerId(params);
        var customerRecord = loadCustomerRecord(customerId);
        updateCustomerFields(customerRecord, params);
        updateAddressBook(customerRecord, params.addressbook);
        var updatedCustomerId = customerRecord.save();
    
        return JSON.stringify({
          success: true,
          message: 'Customer updated successfully. Customer ID is ' + updatedCustomerId
        });
      } catch (e) {
        log.error("Error in doPut", e);
        return JSON.stringify({
          success: false,
          error: e.message || "An error occurred."
        });
      }
    }
    
    function getCustomerId(params) {
      var customerId = params.internalid;
      
      if (!customerId) {
        throw new Error("Missing 'internalid' parameter.");
      }
      
      return customerId;
    }
    
    function loadCustomerRecord(customerId) {
      return record.load({
        type: 'customer',
        id: customerId,
        isDynamic: true
      });
    }
    
    function updateCustomerFields(customerRecord, params) {
      if (params.isperson) {
        customerRecord.setValue({
          fieldId: 'isperson',
          value: 'T'
        });
    
        customerRecord.setValue({
          fieldId: 'firstname',
          value: params.firstname
        });
    
        customerRecord.setValue({
          fieldId: 'middlename',
          value: params.middlename
        });
    
        customerRecord.setValue({
          fieldId: 'lastname',
          value: params.lastname
        });
      } else {
        customerRecord.setValue({
          fieldId: 'companyname',
          value: params.name
        });
      }
    
      if (params.email && isValidEmail(params.email)) {
        customerRecord.setValue({
          fieldId: 'email',
          value: params.email
        });
      }
    
      if (params.website) {
        if (!isValidWebsite(params.website)) {
          throw new Error("Invalid website format.");
        }
    
        customerRecord.setValue({
          fieldId: 'url',
          value: params.website
        });
      }
    
      if (params.phone) {
        if (params.phone.length >= 7) {
          customerRecord.setValue({
            fieldId: 'phone',
            value: params.phone
          });
        } else {
          throw new Error("Phone number should have seven digits or more.");
        }
      }
    
      if (params.subsidiary) {
        customerRecord.setValue({
          fieldId: 'subsidiary',
          value: params.subsidiary
        });
      }
    }
    
    function updateAddressBook(customerRecord, addresses) {
      if (!addresses || addresses.length === 0) {
        return;
      }
    
      var lineCount = customerRecord.getLineCount({ sublistId: 'addressbook' });
    
      for (var i = lineCount - 1; i >= 0; i--) {
        customerRecord.removeLine({ sublistId: 'addressbook', line: i });
      }
    
      for (var i = 0; i < addresses.length; i++) {
        var address = addresses[i];
        customerRecord.selectNewLine({ sublistId: 'addressbook' });
    
        customerRecord.setCurrentSublistValue({
          sublistId: 'addressbook',
          fieldId: 'defaultbilling',
          value: address.defaultbilling
        });
    
        customerRecord.setCurrentSublistValue({
          sublistId: 'addressbook',
          fieldId: 'defaultshipping',
          value: address.defaultshipping
        });
    
        customerRecord.setCurrentSublistValue({
          sublistId: 'addressbook',
          fieldId: 'label',
          value: address.label
        });
    
        var addressSubrecord = customerRecord.getCurrentSublistSubrecord({
          sublistId: 'addressbook',
          fieldId: 'addressbookaddress'
        });
    
        addressSubrecord.setValue({
          fieldId: 'attention',
          value: address.attention
        });
    
        addressSubrecord.setValue({
          fieldId: 'addr1',
          value: address.address1
        });
    
        addressSubrecord.setValue({
          fieldId: 'addr2',
          value: address.address2
        });
    
        addressSubrecord.setValue({
          fieldId: 'city',
          value: address.city
        });
    
        addressSubrecord.setValue({
          fieldId: 'state',
          value: address.state
        });
    
        addressSubrecord.setValue({
          fieldId: 'zip',
          value: address.zip
        });
    
        addressSubrecord.setValue({
          fieldId: 'country',
          value: address.country
        });
    
        customerRecord.commitLine({ sublistId: 'addressbook' });
      }
    }
      

  return {
    get: doGet,
    post: doPost,
    put: doPut
  };


});