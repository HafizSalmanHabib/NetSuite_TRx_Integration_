/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/record', 'N/format', './moment.js'], function (search, record, format, moment) {

  /**
   * Returns an array of vendor objects with details and addresses based on the provided search criteria.
   * 
   * @param {Object} params - Search criteria object.
   * @param {String} params.name - The name of the vendor to search for.
   * @param {Number} [startIndex=0] - The start index for the search results. Default is 0.
   * @param {Number} [batchSize=50] - The number of search results to return in a batch. Default is 40.
   * 
   * @returns {Array} An array of vendor objects.
   */
  function getVendorBills(params) {
    try {

      var recordType = params.type
      if (!recordType) {
        throw new Error('Please enter the record type.');
      }
      log.debug("recordType", recordType);
      const poSearch = search.create({
        type: recordType,
        columns: [
          'internalid',
          'trandate',
          'tranid',
          'entity',
          'postingperiod',
          'memo',
          'amount',
          'item',
          'account',
          'datecreated',
          'rate',
          'unit',
          'subsidiary',
          'class',
          'location',
          'duedate',
          'approvalstatus',
          'currency'
        ],
        filters: [
          ['mainline', 'is', 'true']
        ]
      });
      log.debug("vendorname", params.vendorname);
      if (params.subsidiaryid) {
        customerSearch.filters.push(search.createFilter({
          name: 'subsidiary',
          operator: 'anyof',
          values: [params.subsidiaryid]
        }));
      }
      if (params.vendorname) {
        customerSearch.filters.push(search.createFilter({
          name: 'entityid',
          operator: 'haskeywords',
          values: [params.vendorname]
        }));
      }

      if (params.vendorId) {
        poSearch.filters.push(search.createFilter({
          name: 'entity',
          operator: 'anyof',
          values: [params.vendorId]
        }));
      }
      log.debug("referencenumber", params.referencenumber);
      if (params.referencenumber) {
        poSearch.filters.push(search.createFilter({
          name: 'tranid',
          operator: 'anyof',
          values: [params.referencenumber]
        }));
      }
      log.debug("params.internalid", params.internalid);
      if (params.internalid) {
        poSearch.filters.push(search.createFilter({
          name: 'internalid',
          operator: 'anyof',
          values: [params.internalid]
        }));
      }

      const searchResultCount = poSearch.runPaged().count;
      const startIndex = params.start || 0;
      const batchSize = params.batchSize || 40;
      const endIndex = parseInt(startIndex) + parseInt(batchSize);
      const searchResults = poSearch.run().getRange({ start: startIndex, end: endIndex });

      const vendorBills = searchResults.map(result => {
        const vendorbillid = result.getValue('internalid');
        log.debug("vendorbillid", vendorbillid);
        var recordType = params.type
        const vendorBillRecord = record.load({
          type: recordType,
          id: vendorbillid,
          isDynamic: true
        });
        // Getting Expense Deatil
        const expenseLineCount = vendorBillRecord.getLineCount({ sublistId: 'expense' });
        log.debug("expenseLineCount", expenseLineCount);
        const billExpenses = [];
        for (let i = 0; i < expenseLineCount; i++) {
          const account = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'account', line: i });
          const accountDisplay = vendorBillRecord.getSublistText({ sublistId: 'expense', fieldId: 'account_display', line: i });
          const amount = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'amount', line: i });
          const location = vendorBillRecord.getSublistText({ sublistId: 'expense', fieldId: 'location', line: i });
          const locationid = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'location', line: i });
          const departmentid = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'department', line: i });
          const department = vendorBillRecord.getSublistText({ sublistId: 'expense', fieldId: 'department', line: i });
          const memo = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'memo', line: i });
          const classIid = vendorBillRecord.getSublistValue({ sublistId: 'expense', fieldId: 'class', line: i });
          const classname = vendorBillRecord.getSublistText({ sublistId: 'expense', fieldId: 'class', line: i });


          billExpenses.push({
            account,
            accountDisplay,
            amount,
            locationid,
            location,
            classIid,
            classname,
            memo,
            departmentid,
            department

          });
        }
        //Getting Item Detail 
        const lineCount = vendorBillRecord.getLineCount({ sublistId: 'item' });
        log.debug("lineCount", lineCount);
        const billitems = [];
        for (let i = 0; i < lineCount; i++) {
          const itemId = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
          const itemName = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'item', line: i });
          const itemDescription = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'description', line: i });
          const itemClassid = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'class', line: i });
          const itemClassname = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'class', line: i });
          const accounts = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'custcol_accounts', line: i });
          const quantity = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
          const rate = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'rate', line: i });
          const amount = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: i });
          const unitid = vendorBillRecord.getSublistValue({ sublistId: 'item', fieldId: 'units', line: i });
          const unitname = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'units', line: i });
          const department = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'department', line: i });
          const customer = vendorBillRecord.getSublistText({ sublistId: 'item', fieldId: 'customer', line: i });

          billitems.push({
            itemId,
            itemName,
            itemDescription,
            itemClassid,
            itemClassname,
            accounts,
            quantity,
            rate,
            amount,
            unitid,
            unitname,
            department,
            customer
          });
        }
        log.debug("items", billitems);
        return {
          internalid: result.getValue('internalid'),
          vendorid: result.getValue('entity'),
          vendorname: result.getText('entity'),
          referencenumber: result.getValue('tranid'),
          trandate: result.getValue('trandate'),
          postingperiodid: result.getValue('postingperiod'),
          postingperiodname: result.getText('postingperiod'),
          memo: result.getValue('memo'),
          amount: result.getValue('amount'),
          accountid: result.getValue('account'),
          accountname: result.getText('account'),
          datecreated: result.getValue('datecreated'),
          subsidiaryid: result.getValue('subsidiary'),
          subsidiaryname: result.getText('subsidiary'),
          locationid: result.getValue('location'),
          locationname: result.getText('location'),
          duedate: result.getValue('duedate'),
          approvalstatusid: result.getValue('approvalstatus'),
          approvalstatusname: result.getText('approvalstatus'),
          currencyid: result.getValue('currency'),
          currencyname: result.getText('currency'),
          items: billitems,
          expenses: billExpenses
        };

      });

      // Return the purchase orders
      return { vendorBills, searchResultCount };
    }
    catch (err) {
      log.debug({
        title: 'Error vendorBills',
        details: err.message
      });
      throw err;
    }
  }


  // Get CAll
  function doGet(params) {
    try {
      log.debug("params", params);
      var vendorBill = getVendorBills(params);
      log.debug("vendors", vendorBill);
      return JSON.stringify({
        success: true,
        vendorBills: vendorBill.vendorBills,
        totalRecords: vendorBill.searchResultCount,
      });
    } catch (e) {
      log.error({
        title: 'Error in doGet',
        details: e.message
      });
      return JSON.stringify({
        success: false,
        error: e.message
      });
    }
  }

  // Post CAll

  // Create vendor code

  function doPost(params) {
    try {
      log.debug("params", params);
      var billId = createRecordFromPO(params);
      log.debug("vendors", billId);
      return JSON.stringify({
        success: true,
        vendorBillId: billId
      });

    } catch (e) {
      log.debug({
        title: 'Error in doPost',
        details: e.message
      });
      return JSON.stringify({
        success: false,
        error: e.message
      });
    }
  }

  function createRecordFromPO(params) {
    let result = {
      error: null,
      vendorBillId: null,
      itemReceiptId: null
    };

    try {

      var PoId = params.purchaseOrderID;
      if (!PoId) throw new Error('Purchase Order ID is required.');
      var PoObj = record.load({
        type: record.Type.PURCHASE_ORDER,
        id: PoId,
        isDynamic: true
      });

      var Po_Status = PoObj.getText({ fieldId: 'approvalstatus' });

      if (typeof Po_Status !== 'undefined' && Po_Status !== 'Approved') {
        throw new Error(`Purchase Order Status is ${Po_Status}`);
      }


      const inventoryItems = params.items.filter(item =>
        item.itemType === 'InvtPart' ||
        item.itemType === 'NonInvtPart' ||
        (item.fulfillable)
      );

      const serviceItems = params.items.filter(item => !item.fulfillable);

      log.debug("inventoryItems", inventoryItems);
      log.debug("serviceItems", serviceItems)
      // When createVendorBill is true
      if (params.createVendorBill == true) {

        if (inventoryItems.length > 0) {
          result.itemReceiptId = createItemReceiptRecord(params, inventoryItems);
        }
        log.debug("createVendorBill Bill Create");

        result.vendorBillId = createVendorBillRecord(params, params.items);
        return result;
      } else {

        if (inventoryItems.length > 0) {
          log.debug("inventoryItems Item Receipt");
          result.itemReceiptId = createItemReceiptRecord(params, inventoryItems);

          if (params.createitemreceiptbill) {
            log.debug("createitemreceiptbill Bill Create");
            var mergedItems = inventoryItems.concat(serviceItems);
            result.inventoryVendorbillId = createVendorBillRecord(params, mergedItems);
          }
          if (serviceItems.length > 0 && !params.createitemreceiptbill) {
            log.debug("serviceItems Bill Create");
            result.vendorBillId = createVendorBillRecord(params, serviceItems);
          }
        }

        return result;
      }

    } catch (err) {
      log.debug({ title: 'Error createvendorbill', details: err.message });
      result.error = err.message;
      return result;
    }
  }
  function parseAndFormatDateString(trandate, subsidiaryid) {
    var subsidiaryRecord = record.load({
        type: record.Type.SUBSIDIARY,
        id: subsidiaryid
    });

    var desiredFormat = subsidiaryRecord.getValue({ fieldId: 'DATEFORMAT' });
    log.debug("Desired Format:", desiredFormat);

    // Use moment.js to format the date
    let formattedDate = moment(trandate).format(desiredFormat);

    log.debug(formattedDate); 

    return formattedDate; 
}


  // Create Vendor Bill Record
  function createVendorBillRecord(params, items) {

    var poId = params.purchaseOrderID;

    const inventoryItems = items;
    const InventoryItemIds = inventoryItems.map(item => parseInt(item.itemid));
    var transformedBill = record.transform({
      fromType: record.Type.PURCHASE_ORDER,
      fromId: poId,
      toType: record.Type.VENDOR_BILL
    });

    var subsidiary = transformedBill.getValue({ fieldId: 'subsidiary' });
    log.debug("subsidiary", subsidiary);
    if (params.memo) transformedBill.setValue('memo', params.memo);
    if (params.locationid) transformedBill.setValue('location', params.locationid);
    if (params.referencenumber) transformedBill.setValue('tranid', params.referencenumber);
    if (params.trandate) {
      var date = parseAndFormatDateString(params.trandate, subsidiary)
      log.debug("date", date);
       var formattedDate = format.parse({ value: date, type: format.Type.DATE });
      transformedBill.setValue('trandate', formattedDate);
    }
    var lineCount = transformedBill.getLineCount({ sublistId: 'item' });

    for (var i = 0; i < lineCount; i++) {
      var itemId = transformedBill.getSublistValue({
        sublistId: 'item',
        fieldId: 'item',
        line: i
      });
      log.debug("itemId_matchingItem", itemId);
      // Decrement the counter and line count: Every time you remove a line from a record, 
      // the total number of lines decreases by 1, and all lines after the removed line will shift up by 1. 
      // Therefore, you should decrement both the loop counter i and the lineCount variable to account for this.
      //  This is necessary to prevent skipping any lines and to avoid out-of-bound errors.
      var matchingItem = inventoryItems.find(item => parseInt(item.itemid) === parseInt(itemId));

      log.debug("matchingItem", matchingItem);
      if (!matchingItem) { // Using indexOf method
        log.debug(`item removed ${itemId}`);
        transformedBill.removeLine({
          sublistId: 'item',
          line: i
        });
        i--;
        lineCount--;
        continue;

      }

      log.debug("matchingItem.quantity", matchingItem.quantity);
      if (matchingItem.quantity) {
        log.debug("matchingItem.quantity else", matchingItem.quantity);
        transformedBill.setSublistValue({
          sublistId: 'item',
          fieldId: 'quantity',
          line: i,
          value: matchingItem.quantity
        });
      }
      if (matchingItem.rate) {
        transformedBill.setSublistValue({
          sublistId: 'item',
          fieldId: 'rate',
          line: i,
          value: matchingItem.rate
        });

      }
    }

    var billId = transformedBill.save();

    return {
      message: "Bill created successfully.",
      billId: billId
    };
  }

  // Create Item Receipt Record
  function createItemReceiptRecord(param, items) {
    try {
      var purchaseOrderId = param.purchaseOrderID;

      const inventoryItems = items
      //log.debug("inventoryItems", inventoryItems);
      var itemReceiptRecord = record.transform({
        fromType: record.Type.PURCHASE_ORDER,
        fromId: purchaseOrderId,
        toType: record.Type.ITEM_RECEIPT,
        isDynamic: true
      });
      if (param.vendorid) {
        itemReceiptRecord.setText({
          fieldId: 'entity',
          value: param.vendorname
        });
      }

      // Update the reference number if it exists in the parameters
      if (param.referencenumber) {
        itemReceiptRecord.setValue({
          fieldId: 'tranid',
          value: param.referencenumber
        });
      }

      // Update the account if it exists in the parameters
      if (param.account) {
        itemReceiptRecord.setValue({
          fieldId: 'account',
          value: param.account
        });
      }

      // Update the currency if it exists in the parameters
      if (param.currency) {
        itemReceiptRecord.setValue({
          fieldId: 'currency',
          value: param.currency
        });
      }

      // Update the exchange rate if it exists in the parameters
      if (param.exchangerate) {
        itemReceiptRecord.setValue({
          fieldId: 'exchangerate',
          value: param.exchangerate
        });
      }

      // Update the memo if it exists in the parameters
      if (param.memo) {
        itemReceiptRecord.setValue({
          fieldId: 'memo',
          value: param.memo
        });
      }

      // Update the subsidiary if it exists in the parameters
      if (param.subsidiary) {
        itemReceiptRecord.setValue({
          fieldId: 'subsidiary',
          value: parseInt(param.subsidiary)
        });
      }

      // Update the location if it exists in the parameters
      if (param.location) {
        itemReceiptRecord.setValue({
          fieldId: 'location',
          value: param.location
        });
      }


      var lineCount = itemReceiptRecord.getLineCount({
        sublistId: 'item'
      });
      log.debug("lineCount", lineCount);
      // for (var i = 0; i < lineCount; i++) {
      //   var itemId = itemReceiptRecord.getSublistValue({
      //     sublistId: 'item',
      //     fieldId: 'item',
      //     line: i
      //   });
      //   log.debug("itemId", itemId);
      //   itemReceiptRecord.selectLine({
      //     sublistId: 'item',
      //     line: i
      //   });

      // Check if the item exists in the itemMap
      for (var i = 0; i < lineCount; i++) {
        var itemId = itemReceiptRecord.getSublistValue({
          sublistId: 'item',
          fieldId: 'item',
          line: i
        });

        var matchingItem = inventoryItems.find(item => item.itemid === itemId);
        if (matchingItem) {
          log.debug("ItemFound", itemId);
          itemReceiptRecord.selectLine({
            sublistId: 'item',
            line: i
          });
          itemReceiptRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'itemreceive',
            value: true
          });
          itemReceiptRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'quantity',
            value: matchingItem.quantity
          });
          itemReceiptRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'rate',
            value: matchingItem.rate
          });
          itemReceiptRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'location',
            value: matchingItem.locationid
          });
          itemReceiptRecord.commitLine({
            sublistId: 'item'
          });
        } else {
          itemReceiptRecord.selectLine({
            sublistId: 'item',
            line: i
          });
          itemReceiptRecord.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'itemreceive',
            value: false
          });
          itemReceiptRecord.commitLine({
            sublistId: 'item'
          });
        }
      }


      //   itemReceiptRecord.commitLine({
      //     sublistId: 'item'
      //   });
      // }

      var itemReceiptId = itemReceiptRecord.save({
        enableSourcing: true,
        ignoreMandatoryFields: true
      });

      return {
        success: true,
        itemReceiptId: itemReceiptId
      };
    } catch (e) {
      log.error({
        title: 'Error in creating Item Receipt',
        details: e.message
      });

      return {
        error: {
          code: "ITEM_RECEIPT_CREATION_ERROR",
          message: e.message
        }
      };
    }
  }

  // Update the vendor bill
  function updateVendorBill(billId, params) {
    try {
      var recordType = params.type
      var billRecord = record.load({
        type: recordType,
        id: billId,
        isDynamic: true
      });

      // Update the vendor's entity ID if it exists in the parameters
      if (params.vendorid) {
        billRecord.setText({
          fieldId: 'entity',
          value: params.vendorname
        });
      }

      // Update the reference number if it exists in the parameters
      if (params.referencenumber) {
        billRecord.setValue({
          fieldId: 'tranid',
          value: params.referencenumber
        });
      }

      // Update the account if it exists in the parameters
      if (params.account) {
        billRecord.setValue({
          fieldId: 'account',
          value: params.account
        });
      }

      // Update the currency if it exists in the parameters
      if (params.currency) {
        billRecord.setValue({
          fieldId: 'currency',
          value: params.currency
        });
      }

      // Update the exchange rate if it exists in the parameters
      if (params.exchangerate) {
        billRecord.setValue({
          fieldId: 'exchangerate',
          value: params.exchangerate
        });
      }

      // Update the memo if it exists in the parameters
      if (params.memo) {
        billRecord.setValue({
          fieldId: 'memo',
          value: params.memo
        });
      }

      // Update the subsidiary if it exists in the parameters
      if (params.subsidiary) {
        billRecord.setValue({
          fieldId: 'subsidiary',
          value: parseInt(params.subsidiary)
        });
      }

      // Update the location if it exists in the parameters
      if (params.location) {
        billRecord.setValue({
          fieldId: 'location',
          value: params.location
        });
      }

      // Update specific lines if they exist in the parameters
      if (params.lines && params.lines.length > 0) {
        var linesToUpdate = params.lines;

        for (var i = 0; i < linesToUpdate.length; i++) {
          var lineData = linesToUpdate[i];
          var lineIndex = lineData.lineNumber - 1; // Convert line number to index

          if (lineIndex >= 0 && lineIndex < billRecord.getLineCount({ sublistId: 'item' })) {
            billRecord.selectLine({ sublistId: 'item', line: lineIndex });

            if (lineData.quantity) {
              billRecord.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'quantity',
                value: lineData.quantity
              });
            }

            if (lineData.rate) {
              billRecord.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'rate',
                value: lineData.rate
              });
            }

            if (lineData.amount) {
              billRecord.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'amount',
                value: lineData.amount
              });
            }

            // Update other fields for the line as needed
            // ...

            billRecord.commitLine({ sublistId: 'item' });
          }
        }
      }

      // Save the updated vendor bill
      var updatedBillId = billRecord.save({ ignoreMandatoryFields: true });

      return {
        success: true,
        updatedBillId: updatedBillId
      };
    } catch (err) {
      log.debug({
        title: 'Error updateVendorBill',
        details: err.message
      });
      throw err;
    }
  }


  function doPut(params) {
    try {
      var billId = params.internalid; // Assuming the purchase order ID is provided in the request parameters

      if (!billId) {
        throw new Error("Missing 'internalid' parameter.");
      }

      var result = updateVendorBill(billId, params);

      if (!result.success) {
        return JSON.stringify({
          success: false,
          error: result.error
        });
      }

      return JSON.stringify({
        success: true,
        updatedBillId: 'Vendor Bill updated successfully. Updated Bill ID: ' + result.updatedBillId
      });

    } catch (e) {
      log.debug({
        title: 'Error in doPut',
        details: e.message
      });

      return JSON.stringify({
        success: false,
        error: e.message
      });
    }
  }

  return {
    get: doGet,
    post: doPost,
    put: doPut
  };


});