/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */

define(['N/search'], function (search) {
  function getSubsidiaries(params) {
    var subsidiarySearchObj = search.create({
      type: "subsidiary",
      filters: [["isinactive","is","F"]],
      columns: [
        "internalid",
        search.createColumn({
          name: "name",
          sort: search.Sort.ASC
        }),
        "legalname",
        "city",
        "state",
        "country",
        "currency",
        "email",
        "language",
        "phone",
        "taxidnum",
        "iselimination",
        "fax",
        "parent",
        "representingcustomer",
        "representingvendor",
        "address1",
        "address2",
        "zip"
      ]
    });
  
    if (params.name) {
      subsidiarySearchObj.filters.push(
        search.createFilter({
          name: 'name',
          operator: 'contains',
          values: params.name
        })
      );
    }
  
    var searchResult = subsidiarySearchObj.run();
    var subsidiaries = [];
    searchResult.each(function (result) {
      subsidiaries.push({
        internalId: result.getValue("internalid"),
        isinactive: result.getValue("isinactive"),
        name: result.getValue("name"),
        legalName: result.getValue("legalname"),
        city: result.getValue("city"),
        state: result.getValue("state"),
        country: result.getValue("country"),
        currency: result.getValue("currency"),
        parentCurrency: result.getValue("parent"),
        email: result.getValue("email"),
        language: result.getValue("language"),
        phone: result.getValue("phone"),
        taxId: result.getValue("taxidnum"),
        isElimination: result.getValue("iselimination"),
        fax: result.getValue("fax"),
        parent: result.getValue("parent"),
        parentName: result.getValue("parent"),
        representingCustomer: result.getValue("representingcustomer"),
        representingVendor: result.getValue("representingvendor"),
        address1: result.getValue("address1"),
        address2: result.getValue("address2"),
        zip: result.getValue("zip")
      });
      return true;
    });
  
    return subsidiaries;
  }
  
  function doGet(params) {
    try {
      var subsidiaries = getSubsidiaries(params);
      return JSON.stringify({
        success: true,
        subsidiaries: subsidiaries,
        totalSubsidiaries: subsidiaries.length
      });
    } catch (e) {
      console.error("Error in doGet", e);
      return JSON.stringify({
        success: false,
        error: e.message
      });
    }
  }
  
  function doPut(params) {
    try {
      var updatedSubsidiary = updateSubsidiary(params);
  
      return JSON.stringify({
        success: true,
        subsidiary: updatedSubsidiary.internalId + " Subsidiary updated successfully."
      });
      
    } catch (e) {
      return JSON.stringify({
        success: false,
        error: e.message
      });
    }
  }
  
  function updateSubsidiary(params) {
    // Retrieve the internal ID from the params object
    var subsidiaryId = params.internalid;
  
    // Check if the internalid is provided
    if (!subsidiaryId) {
      throw new Error("Missing 'internalid' parameter.");
    }
  
    var subsidiaryRecord = record.load({
      type: 'subsidiary',
      id: subsidiaryId,
      isDynamic: true
    });
  
    // Update the main fields
    if (params.name) {
      subsidiaryRecord.setValue('name', params.name);
    }
    if (params.legalName) {
      subsidiaryRecord.setValue('legalname', params.legalName);
    }
    if (params.email) {
      subsidiaryRecord.setValue('email', params.email);
    }
    if (params.phone) {
      subsidiaryRecord.setValue('phone', params.phone);
    }
    if (params.state) {
      subsidiaryRecord.setText('state', params.state);
    }
    if (params.country) {
      subsidiaryRecord.setText('country', params.country);
    }
    if (params.currency) {
      subsidiaryRecord.setText('currency', params.currency);
    }
    if (params.parentsubsidiary) {
      subsidiaryRecord.setText('parent', params.parentsubsidiary);
    }
  
    // Save the updated subsidiary record
    var updatedSubsidiaryId = subsidiaryRecord.save();
  
    return {
      internalId: updatedSubsidiaryId,
      message: 'Subsidiary updated successfully'
    };
  }
  
  
  
  
  
    return {
      get: doGet
      //put: doPut
    };
  });
  