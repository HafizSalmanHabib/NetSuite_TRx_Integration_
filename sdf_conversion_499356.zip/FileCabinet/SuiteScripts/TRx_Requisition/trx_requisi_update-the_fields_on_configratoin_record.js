/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/https', 'N/log', 'N/runtime', 'N/ui/message', 'N/ui/dialog'], function (currentRecord, https, log, runtime, message, dialog) {

  function pageInit(context) {
    try {
      if (context.mode === 'create') {
        var rec = context.currentRecord;
        var accountId = runtime.accountId;
        rec.setValue({ fieldId: 'custrecord_aacount_id', value: accountId });
       
       // rec.setValue({ fieldId: 'custrecord_trx_link', value: defaultLink });
        // var manulLink = 'https://qaerequisition.e-bizsoft.net/Document/HowToIntegrateNetSuite.pdf';
        // rec.setValue({ fieldId: 'custrecord_requisition_manual', value: manulLink });


      }
    } catch (error) {
      log.debug('Error in Client Script: ' + error.message);
    }
  }

  function fieldChanged(context) {
    var rec = context.currentRecord;
    var fieldId = context.fieldId;

    // Define the source and target field mappings
    var fieldMappings = {
      'custrecord_consumer_key': 'custrecord_consumer_key_copy',
      'custrecord_consumer_secret': 'custrecord_consumer_secret_copy',
      'custrecord_access_token': 'custrecord_access_token_copy',
      'custrecord_token_secret': 'custrecord_token_secret_copy'
    };

    try {
      // Check if the field being changed is a source field
      if (fieldId in fieldMappings && isSourceFieldChanged(fieldId, rec)) {
        var sourceFieldId = fieldId;
        var targetFieldId = fieldMappings[fieldId];

        // Get the value from the source field
        var sourceValue = rec.getValue({ fieldId: sourceFieldId });

        // Set the value to the target field
        rec.setValue({ fieldId: targetFieldId, value: sourceValue });
        //log.debug('Field value copied successfully: ' + sourceFieldId + ' to ' + targetFieldId);
      }
    } catch (error) {
      log.debug('Error copying field value: ' + error.message);
    }
  }

  function isSourceFieldChanged(fieldId, rec) {
    // Define the source field IDs
    var sourceFieldIds = [
      'custrecord_consumer_key',
      'custrecord_consumer_secret',
      'custrecord_access_token',
      'custrecord_token_secret'
    ];

    // Check if the field being changed is one of the source fields
    return sourceFieldIds.includes(fieldId);
  }

  function saveRecord(context) {
    try {
      var rec = context.currentRecord;
      var companyName = rec.getValue({ fieldId: 'custrecord_compant_name' });
      var erequisitionPassword = rec.getValue({ fieldId: 'custrecord_erequisition__user_pass' });
      var erequisitionEmail = rec.getValue({ fieldId: 'custrecord_e_requisition_email' });
      var accountId = rec.getValue({ fieldId: 'custrecord_aacount_id' });
      var consumerKey = rec.getValue({ fieldId: 'custrecord_consumer_key_copy' });
      var consumerSecret = rec.getValue({ fieldId: 'custrecord_consumer_secret_copy' });
      var accessToken = rec.getValue({ fieldId: 'custrecord_access_token_copy' });
      var tokenSecret = rec.getValue({ fieldId: 'custrecord_token_secret_copy' });
      var baseUrl = rec.getValue({ fieldId: 'custrecord_trx_requisi_base_url' });


      var apiUrl = 'https://qaerequisition.e-bizsoft.net/handlers/commonfunctions/savenetsuitelog.ashx';

      var payload = {
        company:companyName,
        accountId: accountId,
        emailid: erequisitionEmail,
        password: erequisitionPassword,
        consumerKey: consumerKey,
        consumerSecret: consumerSecret,
        accessToken: accessToken,
        tokenSecret: tokenSecret,
        baseUrl:baseUrl
      };

      var response = https.post({
        url: apiUrl,
        body: payload
      });

      // Check if the word "successfully" is present in the response body (case-insensitive)
      if (response.body.toLowerCase().indexOf("successfully") !== -1) {
        return true; // "successfully" is found
      } else {
        var msg = response.body;
        // window.alert(msg);
        log.debug('Erro Message ',response.body);
        showDialog(msg)
        return false;
        
      
      }

      // The rest of your code...

      log.debug("response", response.body);

      if (response.code === 200) {
        log.debug('Field values successfully sent to the API.');
      } else {
        log.debug('Failed to send field values to the API.');
      }

    } catch (error) {
      log.debug('Error sending field values: ' + error.message);
    }

    // Return true to allow the event to continue executing

  }

  function showDialog(msg) {

    var myMsg = message.create({
      title: 'Error',
      message: msg,
      type: message.Type.ERROR
    });
    myMsg.show({ duration: 5000 });
  }

  return {
    fieldChanged: fieldChanged,
    saveRecord: saveRecord,
    pageInit: pageInit
  };

});
