/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */

define(['N/search', 'N/log'], function (search, log) {
  function getAccounts(params) {
    var accountSearchObj = search.create({
      type: 'account',
      filters: [ 
       ["isinactive","is","F"]
      ],
      columns: [
        search.createColumn({
          name: 'name',
          sort: search.Sort.ASC,
        }),
        'internalid',
        'displayname',
        'type',
        'description',
        'balance',
       // "availablebalance",
        "subsidiary",
        "isinactive"
      ],
    });
    if (params.subsidiaryid) {
      accountSearchObj.filters.push(search.createFilter({
        name: 'subsidiary',
        operator: 'anyof',
        values: [params.subsidiaryid]
      }));
    }
    if (params.internalid) {
      accountSearchObj.filters.push(search.createFilter({
        name: 'internalid',
        operator: 'anyof',
        values: [params.internalid]
      }));
    }
    if (params.name) {
      accountSearchObj.filters.push(search.createFilter({
        name: 'name',
        operator: 'haskeywords',
        values: [params.name]
      }));
    }
    if (params.type) {
      accountSearchObj.filters.push(search.createFilter({
        name: 'type',
        operator: 'anyof',
        values: [params.type]
      }));
    }
    var searchResultCount = accountSearchObj.runPaged().count;
    var startIndex = params.start || 0;
    var batchSize = params.batchSize || 50;
    var endIndex = parseInt(startIndex) + parseInt(batchSize);
    var searchResults = accountSearchObj.run().getRange({ start: startIndex, end: endIndex });

    var accounts = [];
    searchResults.forEach(function (result) {
      // Process each search result
      var account = {
        internalid: result.getValue('internalid'),
        isinactive: result.getText('isinactive'),
        name: result.getValue({ name: 'name' }),
        displayName: result.getValue('displayname'),
        type: result.getValue('type'),
        description: result.getValue('description'),
        balance: result.getValue('balance'),
        subsidiary: result.getValue('subsidiary'),
       // available_balance: result.getValue({ name: 'availablebalance' })
      };
      accounts.push(account);
    });

    return { accounts: accounts, totalRecords: searchResultCount };
  }

  function doGet(params) {
    try {
      var accounts = getAccounts(params);
      return JSON.stringify({
        success: true,
        accounts: accounts.accounts,
        totalRecords: accounts.totalRecords
      });
    } catch (e) {
      log.error({
        title: 'Error in doGet',
        details: e.message,
      });
      return {
        success: false,
        error: e.message,
      };
    }
  }

  return {
    get: doGet,
  };
});
