/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 * @NModuleScope SameAccount
 */
define(["N/search", "N/record"], function (search, record) {
  
  function getLocationData(params) {
    var locationSearchObj = search.create({
      type: "location",
      filters: [["isinactive","is","F"]],
      columns: [
        search.createColumn({ name: "internalid", label: "Internal ID" }),
        search.createColumn({ name: "name", sort: search.Sort.ASC, label: "Name" }),
        search.createColumn({ name: "subsidiary", label: "Subsidiary" }),
        // Add any other columns as needed
      ],
    });
    
    // Applying the filters similar to the Classification example
    if (params.subsidiaryid) {
      locationSearchObj.filters.push(search.createFilter({
        name: "subsidiary",
        operator: "anyof",
        values: [params.subsidiaryid]
      }));
    }
    
    if (params.internalid) {
      locationSearchObj.filters.push(search.createFilter({
        name: "internalid",
        operator: "anyof",
        values: [params.internalid]
      }));
    }
    if (params.name) {
      locationSearchObj.filters.push(search.createFilter({
        name: "name",
        operator: "contains",
        values: [params.name]
      }));
    }

    var searchResultCount = locationSearchObj.runPaged().count;
    var startIndex = params.startIndex || 0;
    var batchSize = params.batchSize || 100;
    var endIndex = parseInt(startIndex) + parseInt(batchSize);
  
    var searchResults = locationSearchObj.run().getRange({ start: startIndex, end: endIndex });

    var locations = [];
    searchResults.forEach(function (result) {
      locations.push({
        internalid: result.getValue({ name: "internalid" }),
        name: result.getValue({ name: "name" }),
        subsidiary: result.getValue({ name: "subsidiary" }),
      });
    });
  
    return { data: locations, totalRecords: searchResultCount };
  }
  
  function doGet(params) {
    try {
      var data = getLocationData(params);
      return JSON.stringify({
        success: true,
        data: data.data,
        totalRecords: data.totalRecords,
      });
    } catch (e) {
      return {
        success: false,
        error: e.message,
      };
    }
  }

  function createLocation(data) {
    var locationRecord = record.create({
      type: record.Type.LOCATION,
    });
    locationRecord.setValue({ fieldId: "name", value: data.name });
    locationRecord.setValue({ fieldId: "subsidiary", value: data.subsidiary });

    var locationId = locationRecord.save();

    return { success: true, locationId: locationId };
  }

  function doPost(data) {
    try {
      var result = createLocation(data);
      return {
        success: true,
        locationId: result.locationId,
      };
    } catch (e) {
      return {
        success: false,
        error: e.message,
      };
    }
  }

  function updateLocation(params) {
    if (!params.internalId) {
      throw new Error("Missing 'internalId' parameter.");
    }

    var locationRecord = record.load({
      type: record.Type.LOCATION,
      id: params.internalId,
      isDynamic: true,
    });
  
    if (params.name) {
      locationRecord.setValue({ fieldId: "name", value: params.name });
    }
    if (params.subsidiary) {
      locationRecord.setValue({ fieldId: "subsidiary", value: params.subsidiary });
    }

    var updatedLocationId = locationRecord.save();
  
    return {
      internalId: updatedLocationId,
      message: "Location updated successfully",
    };
  }
  
  function doPut(params) {
    try {
      var updatedLocation = updateLocation(params);
      return {
        success: true,
        locationId: updatedLocation.internalId,
        message: "Location updated successfully",
      };
    } catch (e) {
      return {
        success: false,
        error: e.message,
      };
    }
  }
  
  return {
    get: doGet,
    post: doPost,
    put: doPut,
  };
});
