/** 
 * @NApiVersion 2.0
 * @NScriptType userEventScript 
*/
define(['N/record'],

     function(record) {

         return{
             
             afterSubmit : function(context)

             {

             var employee = context.newRecord;
             var empCode = employee.getValue('id');
            // var supervisorName = employee.getText('supervisor');
             var supervisorId = employee.getValue('supervisor');

             log.debug('Employee Code',empCode);
             log.debug('Superisor ID', supervisorId)
            // log.debug('Supervisor Name', supervisorName);
           
            if(context.type == context.UserEventType.CREATE){
                log.debug('test');
                var phonecall = record.create({
                    type : record.type.PHONE_CALL
                });
                phonecall.setValue('title','Call HR for benefits')
                phonecall.setValue('assigned', employee.id)
                phonecall.save();
            }

            }


         }
    
});
